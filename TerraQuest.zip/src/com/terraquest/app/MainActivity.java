package com.terraquest.app;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_FILE = 1001;
    private static final int REQ_PERM = 1002;
    private static final int REQ_CAM_CHOOSER = 1003;
    private static final int REQ_CAM_WEB = 1004;
    private PermissionRequest pendingWebPerm;
    private LocationListener liveListener;
    private volatile Location liveLoc;

    private WebView webView;
    private WebView printView;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraUri;
    private File cameraFile;

    // compass
    private SensorManager sensorManager;
    private Sensor rotationSensor;
    private boolean compassOn = false;
    private volatile float magAzimuth = Float.NaN;
    private final float[] rotMatrix = new float[9];
    private final float[] remapped = new float[9];
    private final float[] orient = new float[3];

    private final SensorEventListener compassListener = new SensorEventListener() {
        public void onSensorChanged(SensorEvent e) {
            SensorManager.getRotationMatrixFromVector(rotMatrix, e.values);
            SensorManager.getOrientation(rotMatrix, orient);
            // Phone held upright instead of flat: use the back camera direction.
            if (Math.abs(orient[1]) > 1.0f) {
                SensorManager.remapCoordinateSystem(rotMatrix,
                        SensorManager.AXIS_X, SensorManager.AXIS_Z, remapped);
                SensorManager.getOrientation(remapped, orient);
            }
            float az = (float) Math.toDegrees(orient[0]);
            if (az < 0) az += 360f;
            magAzimuth = az;
        }

        public void onAccuracyChanged(Sensor sensor, int accuracy) { }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        webView.addJavascriptInterface(new Bridge(), "Android");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    public void run() {
                        boolean wantsCamera = false;
                        for (String r : request.getResources()) {
                            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) wantsCamera = true;
                        }
                        // Only our own bundled page may use the camera.
                        boolean ours = request.getOrigin() != null
                                && "file".equals(request.getOrigin().getScheme());
                        if (!wantsCamera || !ours) {
                            request.deny();
                            return;
                        }
                        if (hasCameraPermission()) {
                            request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                        } else {
                            pendingWebPerm = request;
                            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAM_WEB);
                        }
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                cameraUri = null;
                cameraFile = null;

                boolean wantCamera = params != null && params.isCaptureEnabled();
                boolean wantImage = true;
                if (params != null && params.getAcceptTypes() != null) {
                    wantImage = false;
                    for (String t : params.getAcceptTypes()) {
                        if (t != null && t.contains("image")) wantImage = true;
                    }
                }
                Intent intent;
                if (wantCamera) {
                    if (!hasCameraPermission()) {
                        // Declared CAMERA permission must be granted first, or the camera app launch is refused.
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAM_CHOOSER);
                        return true;
                    }
                    intent = buildCameraIntent();
                    if (intent == null) {
                        toast("No camera app available");
                        finishChooser(null);
                        return true;
                    }
                } else {
                    Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                    pick.addCategory(Intent.CATEGORY_OPENABLE);
                    pick.setType(wantImage ? "image/*" : "*/*");
                    intent = Intent.createChooser(pick, wantImage ? "Choose photo" : "Choose file");
                }
                try {
                    startActivityForResult(intent, REQ_FILE);
                } catch (Exception e) {
                    toast("Could not open: " + e.getMessage());
                    finishChooser(null);
                }
                return true;
            }
        });

        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_PERM);
        }

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        }
        cleanOldCacheFiles();

        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean hasCameraPermission() {
        return Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean granted = grantResults != null && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == REQ_CAM_WEB) {
            if (pendingWebPerm != null) {
                if (granted) {
                    pendingWebPerm.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                } else {
                    pendingWebPerm.deny();
                }
                pendingWebPerm = null;
            }
        } else if (requestCode == REQ_CAM_CHOOSER) {
            if (!granted) {
                toast("Camera permission is off. Allow it in Settings, or use Gallery.");
                finishChooser(null);
                return;
            }
            Intent cam = buildCameraIntent();
            if (cam == null) {
                toast("No camera app available");
                finishChooser(null);
                return;
            }
            try {
                startActivityForResult(cam, REQ_FILE);
            } catch (Exception e) {
                toast("Could not open the camera: " + e.getMessage());
                finishChooser(null);
            }
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private void finishChooser(Uri[] results) {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    private File photoDir() {
        File dir = new File(getCacheDir(), "photos");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private void cleanOldCacheFiles() {
        try {
            File[] files = photoDir().listFiles();
            if (files == null) return;
            long cutoff = System.currentTimeMillis() - 24L * 60L * 60L * 1000L;
            for (File f : files) {
                if (f.lastModified() < cutoff) f.delete();
            }
        } catch (Exception ignored) { }
    }

    /** Camera intent that saves into our own cache via PhotoProvider (works on Android 7 to 15). */
    private Intent buildCameraIntent() {
        try {
            cameraFile = new File(photoDir(), "IMG_" + System.currentTimeMillis() + ".jpg");
            cameraFile.createNewFile();
            cameraUri = Uri.parse("content://" + PhotoProvider.AUTHORITY + "/" + cameraFile.getName());

            int flags = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            cam.setClipData(ClipData.newRawUri("photo", cameraUri));
            cam.addFlags(flags);

            List<ResolveInfo> apps = getPackageManager()
                    .queryIntentActivities(cam, PackageManager.MATCH_DEFAULT_ONLY);
            if (apps == null || apps.isEmpty()) {
                return null;
            }
            for (ResolveInfo ri : apps) {
                grantUriPermission(ri.activityInfo.packageName, cameraUri, flags);
            }
            return cam;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_FILE) {
            return;
        }
        Uri[] results = null;
        if (resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
            } else if (cameraFile != null && cameraFile.exists() && cameraFile.length() > 0) {
                results = new Uri[]{cameraUri};
            } else if (cameraFile != null) {
                toast("The camera did not save the photo. Try again or use Gallery.");
            }
        }
        finishChooser(results);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (compassOn && sensorManager != null) {
            sensorManager.unregisterListener(compassListener);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (compassOn && sensorManager != null && rotationSensor != null) {
            sensorManager.registerListener(compassListener, rotationSensor, SensorManager.SENSOR_DELAY_UI);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView != null && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private Location bestLocation() {
        Location live = liveLoc;
        if (live != null && System.currentTimeMillis() - live.getTime() < 60000L) {
            return live;
        }
        try {
            if (Build.VERSION.SDK_INT >= 23
                    && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                return null;
            }
            final LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (lm == null) return null;
            List<String> providers = lm.getProviders(true);
            Location best = null;
            for (String p : providers) {
                Location l = lm.getLastKnownLocation(p);
                if (l == null) continue;
                if (best == null || l.getAccuracy() < best.getAccuracy()) {
                    best = l;
                }
            }
            if (best == null) {
                // Warm up a fix for the next call.
                final String provider = providers.contains(LocationManager.GPS_PROVIDER)
                        ? LocationManager.GPS_PROVIDER
                        : (providers.isEmpty() ? null : providers.get(0));
                if (provider != null) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            try {
                                lm.requestSingleUpdate(provider, new LocationListener() {
                                    public void onLocationChanged(Location l) { }
                                    public void onStatusChanged(String p, int s, Bundle b) { }
                                    public void onProviderEnabled(String p) { }
                                    public void onProviderDisabled(String p) { }
                                }, Looper.getMainLooper());
                            } catch (Exception ignored) { }
                        }
                    });
                }
            }
            return best;
        } catch (Exception e) {
            return null;
        }
    }

    /** Methods callable from the web page as window.Android.* */
    private class Bridge {

        @JavascriptInterface
        public void share(String text) {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, text);
            startActivity(Intent.createChooser(send, "Share"));
        }

        /** Opens the messaging app with the text ready to send as an SMS (number may be empty). */
        @JavascriptInterface
        public void sms(final String number, final String text) {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        String n = number == null ? "" : number.trim();
                        Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(n)));
                        i.putExtra("sms_body", text);
                        startActivity(i);
                    } catch (Exception e) {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType("text/plain");
                        send.putExtra(Intent.EXTRA_TEXT, text);
                        startActivity(Intent.createChooser(send, "Send"));
                    }
                }
            });
        }

        /** Shares a photo (data URL) with a caption. The caption is also copied, because some apps drop it. */
        @JavascriptInterface
        public void shareImage(String dataUrl, String text) {
            try {
                int comma = dataUrl.indexOf(',');
                byte[] bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
                boolean png = dataUrl.startsWith("data:image/png");
                File f = new File(photoDir(), "share_" + System.currentTimeMillis() + (png ? ".png" : ".jpg"));
                FileOutputStream out = new FileOutputStream(f);
                out.write(bytes);
                out.close();
                Uri uri = Uri.parse("content://" + PhotoProvider.AUTHORITY + "/" + f.getName());
                copyToClipboard(text);
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType(png ? "image/png" : "image/jpeg");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_TEXT, text);
                send.setClipData(ClipData.newRawUri("photo", uri));
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(send, "Share"));
                toast("Caption copied: paste it if the app leaves it out");
            } catch (Exception e) {
                toast("Could not share the photo: " + e.getMessage());
            }
        }

        /** Shares a file (name, mime, base64 content), for example a backup, CSV or report. */
        @JavascriptInterface
        public void shareFile(String name, String mime, String base64) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                String safe = name.replaceAll("[^A-Za-z0-9._-]", "_");
                File f = new File(photoDir(), safe);
                FileOutputStream out = new FileOutputStream(f);
                out.write(bytes);
                out.close();
                Uri uri = Uri.parse("content://" + PhotoProvider.AUTHORITY + "/" + f.getName());
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType(mime);
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_SUBJECT, safe);
                send.setClipData(ClipData.newRawUri(safe, uri));
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(send, "Save or share"));
            } catch (Exception e) {
                toast("Could not share the file: " + e.getMessage());
            }
        }

        /** Keeps the screen on while scanning. */
        @JavascriptInterface
        public void keepAwake(final boolean on) {
            runOnUiThread(new Runnable() {
                public void run() {
                    if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                }
            });
        }

        @JavascriptInterface
        public void copy(String text) {
            copyToClipboard(text);
            toast("Copied");
        }

        @JavascriptInterface
        public void openMaps(double lat, double lon, String label) {
            try {
                String q = lat + "," + lon;
                Uri geo = Uri.parse("geo:" + q + "?q=" + q + "(" + Uri.encode(label) + ")");
                startActivity(new Intent(Intent.ACTION_VIEW, geo));
            } catch (Exception e) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://maps.google.com/?q=" + lat + "," + lon)));
                } catch (Exception e2) {
                    toast("No maps app found");
                }
            }
        }

        /** Opens Android's print dialog for an HTML report. Choose "Save as PDF" there. */
        @JavascriptInterface
        public void printHtml(final String html, final String jobName) {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        printView = new WebView(MainActivity.this);
                        printView.setWebViewClient(new WebViewClient() {
                            @Override
                            public void onPageFinished(WebView view, String url) {
                                PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                                pm.print(jobName, view.createPrintDocumentAdapter(jobName),
                                        new PrintAttributes.Builder().build());
                            }
                        });
                        printView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
                    } catch (Exception e) {
                        toast("Could not open print: " + e.getMessage());
                    }
                }
            });
        }

        /** Returns "lat,lon,accuracy" or "" when no fix is available yet. */
        @JavascriptInterface
        public String getLocation() {
            Location best = bestLocation();
            if (best == null) return "";
            return best.getLatitude() + "," + best.getLongitude() + "," + best.getAccuracy();
        }

        /** Starts continuous GPS updates (used while tracking or scanning). */
        @JavascriptInterface
        public void locationStart() {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        if (liveListener != null) return;
                        if (Build.VERSION.SDK_INT >= 23
                                && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                                != PackageManager.PERMISSION_GRANTED) {
                            return;
                        }
                        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                        if (lm == null) return;
                        liveListener = new LocationListener() {
                            public void onLocationChanged(Location l) { liveLoc = l; }
                            public void onStatusChanged(String p, int s, Bundle b) { }
                            public void onProviderEnabled(String p) { }
                            public void onProviderDisabled(String p) { }
                        };
                        if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 1f, liveListener, Looper.getMainLooper());
                        }
                        if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                            lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 4000L, 5f, liveListener, Looper.getMainLooper());
                        }
                    } catch (Exception ignored) { }
                }
            });
        }

        @JavascriptInterface
        public void locationStop() {
            runOnUiThread(new Runnable() {
                public void run() { stopLiveLocation(); }
            });
        }

        /** Starts the compass sensor. Returns false if the phone has no suitable sensor. */
        @JavascriptInterface
        public boolean compassStart() {
            if (sensorManager == null || rotationSensor == null) return false;
            compassOn = true;
            magAzimuth = Float.NaN;
            runOnUiThread(new Runnable() {
                public void run() {
                    sensorManager.registerListener(compassListener, rotationSensor,
                            SensorManager.SENSOR_DELAY_UI);
                }
            });
            return true;
        }

        @JavascriptInterface
        public void compassStop() {
            compassOn = false;
            runOnUiThread(new Runnable() {
                public void run() {
                    if (sensorManager != null) sensorManager.unregisterListener(compassListener);
                }
            });
        }

        /** Returns "magneticDeg,trueDeg,hasDeclination(0/1)" or "" if there is no reading yet. */
        @JavascriptInterface
        public String getHeading() {
            float mag = magAzimuth;
            if (Float.isNaN(mag)) return "";
            float tru = mag;
            int has = 0;
            Location loc = bestLocation();
            if (loc != null) {
                GeomagneticField gf = new GeomagneticField((float) loc.getLatitude(),
                        (float) loc.getLongitude(), (float) loc.getAltitude(),
                        System.currentTimeMillis());
                tru = mag + gf.getDeclination();
                if (tru < 0) tru += 360f;
                if (tru >= 360f) tru -= 360f;
                has = 1;
            }
            return String.format(Locale.US, "%.1f,%.1f,%d", mag, tru, has);
        }
    }

    private void stopLiveLocation() {
        try {
            if (liveListener != null) {
                LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                if (lm != null) lm.removeUpdates(liveListener);
            }
        } catch (Exception ignored) { }
        liveListener = null;
    }

    @Override
    protected void onDestroy() {
        stopLiveLocation();
        super.onDestroy();
    }

    private void copyToClipboard(String text) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("TerraQuest", text));
        } catch (Exception ignored) { }
    }
}
