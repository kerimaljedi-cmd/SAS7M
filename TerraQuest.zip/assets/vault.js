/* TerraQuest Vault planner (2D top view). JSON is compatible with the Subterranea vault format. */
var VKEY = 'tq_vaults_v1', VCUR = 'tq_vault_cur';
var VT = {
 gold_hoard_massive:['💰','#d4a017',1.6,'Massive gold hoard','كومة ذهب ضخمة'],
 gold_pile_medium:['🪙','#c9962a',1,'Gold pile','كومة ذهب'],
 chest_ornate:['🧰','#a0522d',.8,'Ornate chest','صندوق مزخرف'],
 crown_ancient:['👑','#e6c200',.5,'Ancient crown','تاج قديم'],
 ingot_pyramid:['🔶','#d9a400',.9,'Ingot pyramid','هرم سبائك'],
 chalice_cluster:['🏆','#cfa93a',.7,'Chalices','كؤوس'],
 dragon_skull:['💀','#cfc6a8',1.4,'Dragon skull','جمجمة تنين'],
 pillar_carved:['🏛','#8d7f6a',.7,'Carved pillar','عمود منقوش'],
 pillar_stone:['▮','#7a7266',.6,'Stone pillar','عمود حجري'],
 arch_stone:['⌒','#8a8070',1.6,'Stone arch','قوس حجري'],
 wall_slate:['▬','#5c5a58',2.4,'Slate wall','جدار حجري'],
 wall_carved:['▤','#6e6558',2.4,'Carved wall','جدار منقوش'],
 altar_relic:['⛩','#9b8cc4',1,'Relic altar','مذبح أثري'],
 pedestal_stone:['◼','#857a68',.6,'Pedestal','قاعدة'],
 sarcophagus_king:['⚰','#b49a62',1.4,'King sarcophagus','تابوت ملكي'],
 vault_gate_iron:['🚪','#4d5560',1.8,'Iron vault gate','بوابة حديدية'],
 torch_brazier:['🔥','#ff7a2f',.5,'Torch brazier','مشعل'],
 crystal_cluster:['💎','#59c9e8',.8,'Crystals','بلورات'],
 arcane_rune_orb:['🔮','#a35be0',.6,'Rune orb','كرة رونية'],
 magma_geyser:['🌋','#e8431f',1.1,'Magma geyser','نافورة حمم'],
 water_basin:['💧','#3b8bd9',1.4,'Water basin','حوض ماء'],
 spiked_trap:['⚠','#d83a3a',1,'Spiked trap','فخ مسنن'],
 wall_italian_crypt:['✝','#7f7466',2,'Italian crypt wall','جدار سرداب إيطالي'],
 wall_anatolia_glyph:['𓂀','#8f7a55',2,'Anatolian glyph wall','جدار رموز أناضولية'],
 monolith_armenian_khachkar:['✣','#7e7a72',.8,'Khachkar monolith','نصب خاتشكار'],
 tablet_rosetta_cipher:['📜','#b8a074',.7,'Cipher tablet','لوح شفرة']
};
var VTHEMES = ['dragon_hoard','pharaoh_tomb','dwarven_forge','arcane_crypt','sunken_abyss'];
var VFLOORS = {flagstone:['#2c2a27','Flagstone','حجر مرصوف'], water:['#17324a','Water','ماء'], magma:['#3d1a10','Magma','حمم'], obsidian:['#15131c','Obsidian','سبج']};
var VPICK = {
 dragon_hoard:['gold_hoard_massive','gold_pile_medium','dragon_skull','chest_ornate','pillar_stone','crown_ancient','torch_brazier','ingot_pyramid'],
 pharaoh_tomb:['sarcophagus_king','pillar_carved','wall_carved','altar_relic','chest_ornate','torch_brazier','tablet_rosetta_cipher','chalice_cluster'],
 dwarven_forge:['magma_geyser','ingot_pyramid','pillar_stone','wall_slate','torch_brazier','chest_ornate','vault_gate_iron','crystal_cluster'],
 arcane_crypt:['arcane_rune_orb','crystal_cluster','altar_relic','wall_italian_crypt','pedestal_stone','tablet_rosetta_cipher','spiked_trap','torch_brazier'],
 sunken_abyss:['water_basin','pillar_carved','arch_stone','chest_ornate','crystal_cluster','monolith_armenian_khachkar','wall_anatolia_glyph','chalice_cluster']
};
var VFLOOR_OF = {dragon_hoard:'flagstone',pharaoh_tomb:'flagstone',dwarven_forge:'magma',arcane_crypt:'obsidian',sunken_abyss:'water'};
var PX = 40; // pixels per metre; canvas 640 = 16 m

var vault = LS.get(VCUR, null) || {name:'', theme:'dragon_hoard', floorType:'flagstone', objects:[]};
var vsel = -1, vdrag = null;

function vtName(k){ var v = VT[k]; if (!v) return k; return lang === 'ar' ? v[4] : v[3]; }
function vtFloorName(k){ var f = VFLOORS[k]; return lang === 'ar' ? f[2] : f[1]; }
function vSave(){ LS.set(VCUR, vault); }

function vDraw(){
  var cv = $('vtcv'); if (!cv) return;
  var c = cv.getContext('2d'), W = cv.width;
  c.fillStyle = (VFLOORS[vault.floorType] || VFLOORS.flagstone)[0]; c.fillRect(0, 0, W, W);
  c.strokeStyle = 'rgba(255,255,255,.07)'; c.lineWidth = 1;
  for (var i = 0; i <= 16; i++){ c.beginPath(); c.moveTo(i*PX, 0); c.lineTo(i*PX, W); c.moveTo(0, i*PX); c.lineTo(W, i*PX); c.stroke(); }
  c.strokeStyle = 'rgba(255,255,255,.2)'; c.beginPath(); c.moveTo(W/2, 0); c.lineTo(W/2, W); c.moveTo(0, W/2); c.lineTo(W, W/2); c.stroke();
  c.fillStyle = 'rgba(255,255,255,.5)'; c.font = '14px sans-serif'; c.textAlign = 'left'; c.fillText('N ↑', 8, 18);
  vault.objects.forEach(function(o, i){
    var v = VT[o.type]; if (!v) return;
    var x = W/2 + o.position[0]*PX, y = W/2 + o.position[2]*PX, r = Math.max(14, v[2]*(o.scale[0]||1)*PX/2);
    var rot = (o.rotation[1] || 0) * Math.PI / 180;
    c.save(); c.translate(x, y); c.rotate(rot);
    c.fillStyle = v[1]; c.globalAlpha = o.isOpen ? .45 : .9;
    if (v[2] >= 1.6 && /wall|arch|gate/.test(o.type)) c.fillRect(-r, -8, 2*r, 16);
    else { c.beginPath(); c.arc(0, 0, r, 0, 7); c.fill(); }
    c.globalAlpha = 1; c.strokeStyle = i === vsel ? '#fff' : 'rgba(0,0,0,.5)'; c.lineWidth = i === vsel ? 3 : 1;
    if (v[2] >= 1.6 && /wall|arch|gate/.test(o.type)) c.strokeRect(-r, -8, 2*r, 16); else { c.beginPath(); c.arc(0, 0, r, 0, 7); c.stroke(); }
    c.strokeStyle = 'rgba(255,255,255,.8)'; c.lineWidth = 2; c.beginPath(); c.moveTo(0, 0); c.lineTo(0, -r); c.stroke();
    c.restore();
    c.font = Math.round(Math.min(26, Math.max(14, r)) ) + 'px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillStyle = '#fff';
    c.fillText(v[0], x, y); c.textBaseline = 'alphabetic';
  });
}
function vHit(px, py){
  var W = $('vtcv').width, best = -1, bd = 1e9;
  vault.objects.forEach(function(o, i){
    var v = VT[o.type]; if (!v) return;
    var x = W/2 + o.position[0]*PX, y = W/2 + o.position[2]*PX, r = Math.max(20, v[2]*(o.scale[0]||1)*PX/2);
    var d = Math.hypot(px - x, py - y);
    if (d <= r && d < bd){ bd = d; best = i; }
  });
  return best;
}
function vPt(e){ var cv = $('vtcv'), b = cv.getBoundingClientRect(); return [(e.clientX - b.left) * cv.width / b.width, (e.clientY - b.top) * cv.height / b.height]; }

function vFill(){
  var ts = $('vtTheme'), tv = ts.value || vault.theme;
  ts.innerHTML = VTHEMES.map(function(k){ return '<option value="' + k + '">' + esc(t('th_' + k)) + '</option>'; }).join(''); ts.value = vault.theme;
  var fs = $('vtFloor'); fs.innerHTML = Object.keys(VFLOORS).map(function(k){ return '<option value="' + k + '">' + esc(vtFloorName(k)) + '</option>'; }).join(''); fs.value = vault.floorType;
  var ty = $('vtType'), cur = ty.value;
  ty.innerHTML = Object.keys(VT).map(function(k){ return '<option value="' + k + '">' + VT[k][0] + ' ' + esc(vtName(k)) + '</option>'; }).join('');
  if (cur) ty.value = cur;
  $('vtName').value = vault.name || '';
}
function vList(){
  var L = LS.get(VKEY, []);
  $('vtList').innerHTML = L.length ? L.map(function(v, i){
    return '<div class="find"><b>' + esc(v.name || '—') + '</b> <span class="tag">' + esc(t('th_' + v.theme)) + '</span> <span class="sub">' +
      esc(t('vt_count').replace('{n}', v.objects.length)) + '</span><div class="btns"><button class="btn alt" data-vo="' + i + '">' + esc(t('vt_load')) +
      '</button><button class="btn red" data-vd="' + i + '">' + esc(t('delete')) + '</button></div></div>';
  }).join('') : '<div class="sub">' + esc(t('vt_none')) + '</div>';
}
function vaultRender(){
  if (!$('vtcv')) return;
  vFill(); vList();
  $('vtCount').textContent = t('vt_count').replace('{n}', vault.objects.length);
  vDraw();
}
function vaultEnter(){ vaultRender(); }

function vNorm(o){
  if (!o || !VT[o.type]) return null;
  var p = o.position || [0,0,0], s = o.scale || [1,1,1], r = o.rotation || [0,0,0];
  var cl = function(n, a, b){ n = +n; if (isNaN(n)) n = 0; return Math.max(a, Math.min(b, n)); };
  return {type:o.type, position:[cl(p[0],-8,8), cl(p[1],0,4), cl(p[2],-8,8)], rotation:[0, ((+r[1])||0) % 360, 0], scale:[cl(s[0]||1,.3,4), cl(s[1]||1,.3,4), cl(s[2]||1,.3,4)], isOpen: !!o.isOpen};
}
function vAdd(type, x, z){
  vault.objects.push({type:type, position:[x||0, 0, z||0], rotation:[0,0,0], scale:[1,1,1], isOpen:false});
  vsel = vault.objects.length - 1; vSave(); vaultRender();
}
function vRandom(){
  var th = $('vtTheme').value || vault.theme, pick = VPICK[th], n = 14 + Math.floor(Math.random() * 13), objs = [];
  vault.theme = th; vault.floorType = VFLOORS[$('vtFloor').value] && $('vtFloor').value !== vault.floorType ? $('vtFloor').value : VFLOOR_OF[th];
  for (var i = 0; i < n; i++){
    var ty = pick[Math.floor(Math.random() * pick.length)], a = Math.random() * 6.283, rad = 1.5 + Math.random() * 5.5;
    if (/wall|arch|gate/.test(ty)){ a = Math.random() * 6.283; rad = 5 + Math.random() * 2.5; }
    objs.push({type:ty, position:[+(Math.cos(a)*rad).toFixed(2), 0, +(Math.sin(a)*rad).toFixed(2)], rotation:[0, Math.round(Math.random()*359), 0], scale:[+(0.8+Math.random()*0.8).toFixed(2), 1, +(0.8+Math.random()*0.8).toFixed(2)], isOpen:false});
  }
  vault.objects = objs; vsel = -1; vSave(); vaultRender();
}
function vText(){
  var counts = {}; vault.objects.forEach(function(o){ counts[o.type] = (counts[o.type] || 0) + 1; });
  return '🏛 ' + (vault.name || t('vt_title')) + ' (' + t('th_' + vault.theme) + ')\n' +
    Object.keys(counts).map(function(k){ return '• ' + counts[k] + ' × ' + vtName(k); }).join('\n') + '\n\n' + t('share_footer');
}

function vaultInit(){
  var cv = $('vtcv');
  cv.addEventListener('pointerdown', function(e){
    var p = vPt(e), i = vHit(p[0], p[1]); vsel = i;
    if (i >= 0){ var o = vault.objects[i]; vdrag = {dx: p[0] - (cv.width/2 + o.position[0]*PX), dy: p[1] - (cv.width/2 + o.position[2]*PX)}; try { cv.setPointerCapture(e.pointerId); } catch(x){} }
    vDraw();
  });
  cv.addEventListener('pointermove', function(e){
    if (!vdrag || vsel < 0) return;
    var p = vPt(e), o = vault.objects[vsel];
    o.position[0] = Math.max(-8, Math.min(8, +((p[0] - vdrag.dx - cv.width/2) / PX).toFixed(2)));
    o.position[2] = Math.max(-8, Math.min(8, +((p[1] - vdrag.dy - cv.width/2) / PX).toFixed(2)));
    vDraw();
  });
  var up = function(){ if (vdrag){ vdrag = null; vSave(); } };
  cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
  $('vtName').oninput = function(){ vault.name = this.value; vSave(); };
  $('vtTheme').onchange = function(){ vault.theme = this.value; vSave(); };
  $('vtFloor').onchange = function(){ vault.floorType = this.value; vSave(); vDraw(); };
  $('vtAdd').onclick = function(){ vAdd($('vtType').value, 0, 0); };
  var sel = function(f){ return function(){ if (vsel < 0 || !vault.objects[vsel]) return; f(vault.objects[vsel]); vSave(); vDraw(); }; };
  $('vtRot').onclick = sel(function(o){ o.rotation[1] = (o.rotation[1] + 45) % 360; });
  $('vtBig').onclick = sel(function(o){ o.scale = o.scale.map(function(n){ return Math.min(4, +(n*1.2).toFixed(2)); }); });
  $('vtSmall').onclick = sel(function(o){ o.scale = o.scale.map(function(n){ return Math.max(.3, +(n/1.2).toFixed(2)); }); });
  $('vtOpen').onclick = sel(function(o){ o.isOpen = !o.isOpen; });
  $('vtDel').onclick = function(){ if (vsel < 0) return; vault.objects.splice(vsel, 1); vsel = -1; vSave(); vaultRender(); };
  $('vtRand').onclick = vRandom;
  $('vtClear').onclick = function(){ if (vault.objects.length && !confirm(t('confirm_del'))) return; vault.objects = []; vsel = -1; vSave(); vaultRender(); };
  $('vtSave').onclick = function(){
    var L = LS.get(VKEY, []); vault.name = $('vtName').value || vault.name || 'Vault';
    L.unshift(JSON.parse(JSON.stringify(vault))); LS.set(VKEY, L.slice(0, 30)); vSave(); vList();
  };
  $('vtShare').onclick = function(){ vsel = -1; vDraw(); shareText(vText(), $('vtcv').toDataURL('image/jpeg', 0.85)); };
  $('vtJson').onclick = function(){ shareFile('vault-' + (vault.name || 'plan').replace(/[^\w\-]+/g, '_') + '.json', 'application/json', JSON.stringify(vault, null, 2)); };
  $('vtImp').onclick = function(){ $('vtFile').click(); };
  $('vtFile').onchange = function(){
    var f = this.files[0]; if (!f) return; var r = new FileReader(); this.value = '';
    r.onload = function(){
      try {
        var j = JSON.parse(r.result), arr = Array.isArray(j) ? j : j.objects;
        var objs = (arr || []).map(vNorm).filter(Boolean);
        if (!objs.length) throw 0;
        vault = {name: (!Array.isArray(j) && (j.name || j.title)) || '', theme: (j.theme && VPICK[j.theme]) ? j.theme : 'dragon_hoard', floorType: (j.floorType && VFLOORS[j.floorType]) ? j.floorType : 'flagstone', objects: objs};
        vsel = -1; vSave(); vaultRender();
      } catch(e){ alert(t('vt_bad')); }
    };
    r.readAsText(f);
  };
  $('vtList').onclick = function(e){
    var b = e.target.closest ? e.target.closest('button') : null; if (!b) return;
    var L = LS.get(VKEY, []);
    if (b.hasAttribute('data-vo')){ vault = JSON.parse(JSON.stringify(L[+b.getAttribute('data-vo')])); vsel = -1; vSave(); vaultRender(); }
    else if (b.hasAttribute('data-vd')){ L.splice(+b.getAttribute('data-vd'), 1); LS.set(VKEY, L); vList(); }
  };
  vaultRender();
}
vaultInit();
