/* Built-in reference library transcribed from the "Code Reader" Yamashita decoding charts supplied by the user.
   These are folklore / treasure-hunter chart readings, not verified history. Works fully offline. */
(function(){
var WARN = 'WWII-era ordnance or booby traps may still exist. Do not dig or touch. Keep away and report it to the police or bomb-disposal unit.';
// [id, glyph, name, shapes, category, English meaning, Arabic meaning, dangerous]
var Y = [
 // ---- direction & distance
 ['arrow_way','➤','Arrow way',['arrow'],'Direction','Arrow: the way to follow.','سهم: الاتجاه الذي يجب اتباعه.'],
 ['pointer','→','Treasure pointer',['arrow'],'Direction','Points toward the treasure. A pointer can also be a metal bar or rod (1 inch or more thick, about 1 m long) laid toward the cache.','مؤشر الكنز: يشير نحو الكنز. وقد يكون قضيباً معدنياً (سمكه بوصة أو أكثر وطوله نحو متر) موضوعاً باتجاه المخبأ.'],
 ['pointer_2m','⇉','Point to object: 2 metres',['arrow','lines'],'Direction','Double arrow: the object lies 2 metres in the pointed direction. A precise point marker.','سهم مزدوج: الهدف على بعد مترين في الاتجاه المشار إليه. علامة نقطة دقيقة.'],
 ['opposite','⇇','Opposite direction',['arrow'],'Direction','Go the opposite way from the arrow or the way you were heading.','اذهب عكس الاتجاه الذي يشير إليه السهم أو الذي كنت تسير فيه.'],
 ['pointing_down','⇊','Pointing downward: treasure',['arrow','vee'],'Direction','Stacked chevrons or arrows pointing down: the treasure is directly below.','أسهم أو شيفرونات متراصة تشير للأسفل: الكنز تحت هذا الموضع مباشرة.'],
 ['change_dir','◌','Stop, change of direction',['arc','dots'],'Direction','Stop here and turn. Four small circles in a block also mean change of direction.','قف هنا وانعطف. أربع دوائر صغيرة في كتلة تعني أيضاً تغيّر الاتجاه.'],
 ['divided','⤧','Treasure divided as shown',['xmark','arrow'],'Direction','The treasure is split into parts in the directions shown by the arrows.','الكنز مقسّم إلى أجزاء في الاتجاهات التي تبيّنها الأسهم.'],
 ['x_line','✕','Line of treasure or landmark',['xmark'],'Direction','An X marks a line of treasure or a landmark to line up with. Cross-bearing point: two lines intersect here.','علامة X تدل على خط الكنز أو معلَم للمحاذاة. نقطة تقاطع اتجاهين.'],
 ['directly_under','⊗','Treasure directly under',['circle','xmark','square'],'Direction','A circle or box with an X: the treasure is directly under this mark.','دائرة أو مربع بعلامة X: الكنز تحت هذه العلامة مباشرة.'],
 ['straight','◇','Straight',['diamond','arrow'],'Direction','Go straight on.','سِر مستقيماً.'],
 ['trail_end','☞','Trail to treasure; travel ended',['arrow','hand'],'Direction','A pointing hand: the trail to the treasure ends here.','يد تشير: ينتهي الطريق إلى الكنز هنا.'],
 ['lines_dist','═','Short, long and double lines (distance)',['lines'],'Distance','A short line is a short distance, a long line a long distance, a double line double the distance of one.','خط قصير: مسافة قصيرة، خط طويل: مسافة طويلة، خط مزدوج: ضعف مسافة الخط المفرد.'],
 ['yards','5 20 50','Distance marks in yards',['lines','wavy'],'Distance','Chart values: 5 yards ≈ 4.5 m, 20 yards ≈ 18 m, 50 yards ≈ 46 m, 2 m = precise point. A sun with 9 spokes (Korean sign) means 11 yards, 7 spokes means 7 below.','قيم الجدول: 5 ياردات ≈ 4.5 م، 20 ياردة ≈ 18 م، 50 ياردة ≈ 46 م، مترين = نقطة دقيقة. شمس ذات 9 أشعة (علامة كورية) تعني 11 ياردة، و7 أشعة تعني 7 تحت.'],
 ['sun_spokes','☼','Spoked sun: spokes count',['sun'],'Distance','Count the spokes: the number gives yards or a depth. Korean sign: 9 spokes = 11 yards. Also glittering diamonds or a mineral deposit.','عدّ الأشعة: العدد يدل على ياردات أو عمق. علامة كورية: 9 أشعة = 11 ياردة. وقد تعني أيضاً ألماساً متلألئاً أو معدناً.'],
 ['dots_count','∴','Dots: number or distance',['dots'],'Distance','The number of dots or small marks gives a distance, a depth, a number of days or months, or a count of loads or guards.','عدد النقاط أو العلامات الصغيرة يدل على مسافة أو عمق أو عدد أيام أو أشهر أو عدد أحمال أو حراس.'],
 ['days_months','◍','Dotted circle: days or months',['circle','dots'],'Distance','A circle with dots: the dots count days or months.','دائرة بنقاط: النقاط تعدّ الأيام أو الأشهر.'],
 ['depth_6','6+','Deep deposits: 6+ yards',['dots'],'Distance','Chart note: deep deposits lie 6 or more yards down. A sideways shift of about 1 yard is common, so check all hidden signs.','ملاحظة الجدول: الودائع العميقة على عمق 6 ياردات فأكثر. والإزاحة الجانبية بنحو ياردة شائعة، فتفقّد كل العلامات الخفية.'],
 // ---- landmarks
 ['triangle_obj','△','Triangle: object, centre or triangulation',['triangle'],'Landmark','A triangle marks an object or a centre. Treasure lies within the triangle of three trees or stones, on one side of it, or around a bend. Triangulate from three signs.','المثلث يدل على جسم أو مركز. الكنز داخل مثلث من ثلاث أشجار أو حجارة أو على أحد جوانبه أو حول منعطف. حدّد الموقع بالتثليث من ثلاث علامات.'],
 ['double_triangle','▲▲','Double triangle (two big rocks)',['triangle'],'Landmark','Two triangles: two big rocks. They point toward the treasure.','مثلثان: صخرتان كبيرتان. تشيران نحو الكنز.'],
 ['cone_mountain','⛰','Cone-shaped mountain (treasure mountain)',['triangle'],'Landmark','A cone-shaped mountain is a treasure mountain landmark.','جبل مخروطي: معلَم جبل الكنز.'],
 ['salakot','⌓','Salakot (hat) type mountain',['arc'],'Landmark','A hat-shaped mountain: treasure mountain.','جبل على شكل قبعة (سالاكوت): جبل الكنز.'],
 ['mountain_ud','⛰','Mountain sign: up or down',['arrow','triangle'],'Landmark','Go up or down the mountain, as the arrow shows.','اصعد أو انزل الجبل بحسب السهم.'],
 ['big_tree','🌲','Big tree',['tree','circle'],'Landmark','The big tree is a primary triangulation point. The sign is often carved into its roots.','الشجرة الكبيرة نقطة تثليث رئيسية. وكثيراً ما تُنقش العلامة في جذورها.'],
 ['tree_stone','△°','Tree or stone',['tree','triangle'],'Landmark','A tree or a stone used as a marker.','شجرة أو حجر يُستخدم كعلامة.'],
 ['three_rocks','🪨','Three big rocks',['stones'],'Landmark','Three big rocks shaped like a cave door; the top one like a cashew nut, with a rock shaped like an arrowhead pointing down. Usually found on the side of a mountain.','ثلاث صخور كبيرة تشبه باب كهف؛ العليا على شكل ثمرة كاجو، مع صخرة سهمية تشير للأسفل. توجد عادةً على سفح الجبل.'],
 ['arrow_rock','◥','Rock-shaped arrowhead (double-purpose arrow)',['triangle','arrow'],'Landmark','One side points the wrong way and the other the right way. A marker can be found here. It often points down at the object.','أحد الجانبين يشير للاتجاه الخاطئ والآخر للصحيح. قد تجد علامة هنا. وكثيراً ما يشير للأسفل نحو الهدف.'],
 ['church','⛪','Church or chapel',['cross','square'],'Place','Church or chapel only. Treasure under a church is shown by a church sign with a cross.','كنيسة أو كابيلا فقط. الكنز تحت الكنيسة يظهر بعلامة كنيسة مع صليب.'],
 ['cemetery','⌂','Cemetery treasure',['square','vee'],'Place','Treasure at a cemetery.','كنز في مقبرة.'],
 ['ricefield','⊠','Ricefield treasure',['square','xmark'],'Place','Treasure at a ricefield. A box crossed by an X.','كنز في حقل أرز. مربع تقطعه علامة X.'],
 ['school','◌▫','School or small road',['dots','square'],'Place','Marks a school, or two small circles mean a small road.','يدل على مدرسة، أو دائرتان صغيرتان تعنيان طريقاً صغيراً.'],
 ['monument','∩','Monument',['arc'],'Place','A monument.','نصب تذكاري.'],
 ['waterfalls','⫶','Waterfalls and big baggage',['water','lines'],'Place','Waterfalls; baggage with treasure lies between falls. The distance between the falls often matches the vault depth.','شلالات؛ الأمتعة الكبيرة مع الكنز بين الشلالات. والمسافة بين الشلالات تساوي غالباً عمق الخزنة.'],
 // ---- tunnels & structures
 ['tunnel','⊂⊃','Tunnel',['arc'],'Tunnel','A tunnel. A C-shape or GC-shape: treasure inside a tunnel.','نفق. شكل C أو GC: كنز داخل نفق.'],
 ['tunnel_dir','⊃','Tunnel: blade points to',['arc','arrow'],'Tunnel','The blade or tip of the tunnel sign points toward the tunnel.','طرف علامة النفق يشير نحو النفق.'],
 ['straight_tunnel','∨','Straight tunnel / dig down',['vee'],'Tunnel','A V: a straight tunnel, or dig down.','حرف V: نفق مستقيم، أو احفر للأسفل.'],
 ['anchor_tunnel','⚓','Anchor tunnel',['arc','cross'],'Tunnel','An anchor: a secret tunnel hidden by a tunnel or natural cover. Look for other marks.','مرساة: نفق سري مخفي بنفق آخر أو بغطاء طبيعي. ابحث عن علامات أخرى.'],
 ['underground','⌣','Underground passage',['arc','vee'],'Tunnel','A curved line: an underground passage.','خط منحنٍ: ممر تحت الأرض.'],
 ['closed_tunnel','T','Closed tunnel',['lines'],'Tunnel','A T-shape: the tunnel is closed.','شكل T: النفق مغلق.'],
 ['tunnel_gate','⊓','Tunnel gate',['square'],'Tunnel','A squared arch: the access point to an underground network.','قوس مربع: مدخل شبكة أنفاق تحت الأرض.'],
 ['secret_tunnel','⌒','Secret tunnel hidden by cover',['arc'],'Tunnel','A tunnel hidden by natural cover or concealed first section of a tunnel.','نفق مخفي بغطاء طبيعي أو بقسم أول مموّه.'],
 ['hole_type','⩌','Hole type',['arc','lines'],'Tunnel','A hole-type entrance.','مدخل على شكل حفرة.'],
 ['shaft','#','Shaft type',['lattice','lines'],'Tunnel','A grid or hash: a deep, multi-level shaft. Use the direction signs to move between levels.','شبكة أو علامة #: بئر عميق متعدد الطبقات. استخدم علامات الاتجاه للتنقل بين الطبقات.',true],
 ['in_shaft','⏚','In shaft or cave',['lines'],'Tunnel','Inside a shaft or a cave.','داخل بئر أو كهف.',true],
 ['slope_cave','⊔','In slope or cave',['square','vee'],'Tunnel','Treasure in a slope or cave.','كنز في منحدر أو كهف.'],
 ['stairs','⌐','Stairs',['lines','square'],'Structure','Stairs. A step shape: a change of height or passage type.','درج. شكل درجات: تغيّر في الارتفاع أو نوع الممر.'],
 ['stairs_down','⌸','Stairs going down (digging or shaft)',['lines','square'],'Structure','A ladder-like sign: stairs going down into a shaft or digging.','علامة تشبه السلّم: درج ينزل إلى بئر أو حفرة.',true],
 ['stairs_cave','⌐▮','Flight of steps in treasure cave',['lines'],'Structure','A flight of steps inside the treasure cave.','سلّم درجات داخل كهف الكنز.'],
 ['door','▭▭','Door',['square'],'Structure','A door. It needs a specific keystone. False doors (traps) are common.','باب. يحتاج حجر مفتاح محدداً. الأبواب الزائفة (الفخاخ) شائعة.',true],
 ['wall','▤','Wall',['lines','square'],'Structure','A wall.','جدار.'],
 ['opening','⊙','Opening',['dots','stones'],'Structure','The opening is often not visible. Look for specific stacked rocks. The number of dots can show the distance.','المدخل غالباً غير ظاهر. ابحث عن صخور مكدّسة مخصوصة. وعدد النقاط قد يدل على المسافة.'],
 ['floor','⊥','Floor',['lines'],'Structure','The floor. Check for a false floor.','الأرضية. تحقّق من وجود أرضية زائفة.',true],
 ['inside','▫','Inside',['square'],'Structure','The object is inside.','الشيء في الداخل.'],
 ['object_inside','中','Object inside',['square','lines'],'Structure','A box crossed by a line: the object is inside.','مربع يقطعه خط: الشيء في الداخل.'],
 ['hard_cement','☁','Hard cement (needs breaking)',['circle'],'Structure','A cloud-like blob: the object is sealed with hard cement and needs breaking.','شكل يشبه السحابة: الشيء مختوم بإسمنت صلب ويحتاج إلى كسر.'],
 ['stop_dig','⊏3','Stop digging: trap or fake',['square','xmark'],'Danger','Stop digging: this is a trap or a fake.','توقف عن الحفر: هذا فخ أو مزيّف.',true],
 // ---- valuables
 ['gold_bars','⏶','Gold bars',['triangle','lines'],'Valuables','Gold bars. Stacked bars: the size of the stack suggests the size of the cache. Chart counts: 9, 30 or 50 bars.','سبائك ذهب. تكديس السبائك يدل على حجم المخبأ. أعداد الجدول: 9 أو 30 أو 50 سبيكة.'],
 ['gold_boxes','▭B','Boxes of gold bars',['square','lines'],'Valuables','Boxes or chests of gold bars.','صناديق من سبائك الذهب.'],
 ['gold_letter','E','Gold (letter-like sign)',['lines'],'Valuables','Chart reading: gold or money. Look for matching serial marks on nearby stones.','قراءة الجدول: ذهب أو مال. ابحث عن علامات تسلسلية مطابقة على الحجارة القريبة.'],
 ['silver','//','Silver',['lines'],'Valuables','Two slanted strokes or similar kanji variants: silver. Also a silver deposit.','شرطتان مائلتان أو أشكال كانجي مشابهة: فضة. وقد تعني أيضاً مخزون فضة.'],
 ['jewelry','⌘','Jewellery',['lines'],'Valuables','Jewellery. Variants may mean jewel deposit, jewellery and money, or a decoy used to divert from larger gold.','مجوهرات. الاختلافات قد تعني مخزون جواهر أو مجوهرات ومال، أو طُعماً لتحويل الانتباه عن ذهب أكبر.'],
 ['diamond_style','◇','Diamond',['diamond'],'Valuables','A diamond: a high-value specific cache. Often used as a decoy; follow carefully.','معيّن (ألماس): مخبأ عالي القيمة. يُستخدم أحياناً كطُعم؛ تابع بحذر.'],
 ['glitter','✺','Glittering diamonds',['sun','lines'],'Valuables','Glittering diamonds, different kinds, or unfinished products. An uncut stone is shown as a peaked or star shape.','ألماس متلألئ بأنواع مختلفة أو منتجات غير مكتملة. والحجر غير المصقول يُرسم بشكل مدبّب أو نجمة.'],
 ['uncut_stone','Λ','Uncut precious stone',['vee','triangle'],'Valuables','A peak shape: uncut precious stone.','شكل قمة: حجر كريم غير مصقول.'],
 ['coins','⛁','Coins and barrel',['circle'],'Valuables','Coins, or coins and a barrel.','عملات، أو عملات وبرميل.'],
 ['box_chest','▭','Treasure in box or chest',['square'],'Valuables','Treasure in a box or chest. A box with a dot: treasure in a cement box.','كنز في صندوق. مربع بنقطة: كنز في صندوق إسمنتي.'],
 ['round_metal','◯','Piece of round metal',['circle'],'Valuables','A round metal piece (1 inch or more across, up to 1 m long) is a treasure pointer when laid toward the cache.','قطعة معدن مستديرة (قطرها بوصة أو أكثر وطولها حتى متر) تعمل كمؤشر للكنز إذا وُضعت باتجاه المخبأ.'],
 ['empty_box','▨','Buried empty box',['square'],'Valuables','A buried empty box (wood or metal) used as a treasure pointer.','صندوق فارغ مدفون (خشبي أو معدني) يُستخدم كمؤشر للكنز.'],
 ['jar_shards','◣','Broken jar, glass or china shards',['triangle','stones'],'Valuables','Broken pieces of jar, glass or china: a secondary marker meaning a cache is close. The direction the shards scatter is a clue.','قطع من جرّة أو زجاج أو خزف مكسور: علامة ثانوية تدل على قرب مخبأ. واتجاه تناثر القطع دليل.'],
 ['buddha','☸','Buddha sign',['hand','circle'],'Valuables','A Buddha, face or hand mark: a sacred or disguised site, often near temples. A Buddha-like idol found inside a bottle or vessel means gems below.','علامة بوذا (وجه أو يد): موقع مقدس أو مموّه، غالباً قرب المعابد. وتمثال شبيه ببوذا داخل زجاجة أو وعاء يعني جواهر تحتها.'],
 ['bird','🕊','Bird (Sumatra Buddha / wealth)',['animal'],'Valuables','A bird: next on the trail; wealth; or a Sumatra Buddha mark.','طائر: التالي على الطريق؛ ثروة؛ أو علامة بوذا سومطرة.'],
 ['three_stars','☆☆☆','Three stars',['sun'],'Valuables','Three stars: a confirmed Yamashita treasure site, or another Yamashita treasure nearby.','ثلاث نجوم: موقع كنز ياماشيتا مؤكد، أو كنز آخر قريب.'],
 ['sombrero','⌓','Sombrero (number of persons)',['arc','animal'],'Valuables','A hat shape: the number of persons in a party burial. Treasure may also show the number of persons killed. The stack size shows the cache size.','شكل قبعة: عدد الأشخاص في دفن جماعي. وقد يدل أيضاً على عدد من قُتلوا. وحجم الكومة يدل على حجم المخبأ.'],
 // ---- water
 ['under_water','7M','Treasure under water',['square','water'],'Water','Treasure under water. Specialised retrieval is needed.','كنز تحت الماء. يحتاج استخراجه إلى معدات متخصصة.',true],
 ['water_table','⏑','Deposit in water table or spring',['water'],'Water','A deposit at the water table (submersion) or in a spring.','مخزون عند منسوب المياه الجوفية (غمر) أو في نبع.',true],
 ['river_spring','⊕','River or spring',['circle','water'],'Water','A river or spring.','نهر أو نبع.'],
 ['turtle_fish','🐢','Turtle or fish: signs pointing to water',['animal','water'],'Water','A turtle or a fish points to water.','سلحفاة أو سمكة: تشير إلى الماء.'],
 ['water_pump','🚰','Old water pump / waterwell',['lines','water'],'Water','Water connection implies a multi-level plan. Check water level and lateral shift. A well often hides a side tunnel. Look for a small notch on the handle showing direction; a third master bar may sit behind the casing.','وجود الماء يعني خطة متعددة الطبقات. افحص مستوى الماء والإزاحة الجانبية. البئر يخفي غالباً نفقاً جانبياً. ابحث عن شق صغير على المقبض يبيّن الاتجاه؛ وقد تكون سبيكة ثالثة رئيسية خلف الغلاف.'],
 // ---- snakes
 ['snake_cache','🐍','Wild snake (coiled): treasure cache',['wavy','spiral','animal'],'Snake','A coiled snake: a treasure cache. Warning: a snake cache points to the positioning toward the treasure.','أفعى ملتفة: مخبأ كنز. تحذير: علامة الأفعى تشير إلى موضع الكنز.'],
 ['snake_strike','🐍','Snake in striking position',['wavy','animal','arrow'],'Snake','A striking snake pointing toward the treasure. Also: a snake inside a tunnel pointing to the treasure.','أفعى في وضع الانقضاض تشير نحو الكنز. وأفعى داخل نفق تشير إلى الكنز.'],
 ['golden_snake','∞','Golden snake (treasure underneath)',['wavy','animal'],'Snake','A golden snake: treasure underneath.','أفعى ذهبية: الكنز تحتها.'],
 ['snail','🐚','Spiral shell (big deposit)',['spiral','animal'],'Snake','A spiral shell sign: a big deposit (Thai gold in the chart).','علامة صدفة حلزونية: مخزون كبير (ذهب تايلاندي في الجدول).'],
 ['spiral_path','🌀','Spiral pathways',['spiral'],'Direction','Spiral pathways in the chart key.','مسارات حلزونية في مفتاح الجدول.'],
 // ---- danger
 ['danger','☠','Danger: trap or explosive',['skull','xmark'],'Danger','Danger: a trap or explosive. Typical for these charts: buried pressure plates and tripwires linked to charges.','خطر: فخ أو متفجرات. شائع في هذه الجداول: صفائح ضغط مدفونة وأسلاك عثرة موصولة بشحنات.',true],
 ['booby_trap','✶','Booby trap (star or crossed circle)',['sun','circle','xmark'],'Danger','A star, or a circle with an X: booby trap. Triggers can be nested, so decipher the placement codes.','نجمة، أو دائرة بعلامة X: فخ مفخخ. قد تكون المحفزات متداخلة، فافهم رموز التموضع.',true],
 ['live_bomb','⊗','Live bomb',['circle','xmark','arrow'],'Danger','A circle with an X and arrows: a live bomb.','دائرة بعلامة X وأسهم: قنبلة حيّة.',true],
 ['bomb_tomb','⊤','Bomb inside tomb or stone',['lines','arrow'],'Danger','A bomb is placed inside a tomb or stone.','قنبلة موضوعة داخل قبر أو حجر.',true],
 ['false_floor','▦','False floor',['lattice','square'],'Danger','A false floor over a pit or trap.','أرضية زائفة فوق حفرة أو فخ.',true],
 // ---- Navy line code
 ['navy_code','○ ▬ ❘ ╱ ╲','Imperial Navy line code (0–14)',['lines','circle'],'Navy code','Numeric line signs: 0 path or start point (circle); 1 distance, proceed 1 ri; 2 obstacle or wall, move downhill; 3-4 slope, move uphill; 5 turn or hook, retrace steps; 6 double line; 7 L-shape; 8 corner or turn (90° bend); 9 structure or enclosure, search inside; 10 secure compartment, look for a false floor; 11 depression or gully, descent; 13 boundary or wall (property line); 14 old road or trail, follow the old track.','رموز خطوط البحرية: 0 دائرة نقطة بداية؛ 1 مسافة (تقدّم 1 ري)؛ 2 عائق أو جدار (انزل)؛ 3-4 منحدر (اصعد)؛ 5 التفاف (ارجع على أثرك)؛ 6 خط مزدوج؛ 7 شكل L؛ 8 زاوية أو منعطف 90°؛ 9 بناء أو سور (فتّش بداخله)؛ 10 حجرة آمنة (ابحث عن أرضية زائفة)؛ 11 منخفض أو وادٍ (هبوط)؛ 13 حد أو جدار (خط الملكية)؛ 14 طريق قديم (اتبع الأثر).'],
 ['rising_sun','☀','Rising-sun flag / Imperial chrysanthemum',['sun','circle'],'Navy code','Imperial Japanese Navy emblems (rising sun, 16-petal chrysanthemum). They tell you the origin of a mark; they are not directions. Treat the site as protected heritage.','شعارات البحرية الإمبراطورية اليابانية (الشمس المشرقة، الأقحوان ذو 16 بتلة). تدل على أصل العلامة وليست اتجاهات. اعتبر الموقع تراثاً محمياً.'],
 ['principles','✔','Core decoding principles',[],'Method','1) Triangulate three distinct signs. 2) Look for a correctness or confirmation glyph. 3) Booby traps are built into signs, so the way a sign is drawn can show the trap type. 4) Trust triangulation, decipher decoys, look for cultural markers. 5) Repeat the directional signs, then find the continuation sign. Measure distance from the main marker.','1) ثلّث ثلاث علامات متمايزة. 2) ابحث عن رمز تأكيد. 3) الفخاخ مدمجة في العلامات، فطريقة رسم العلامة قد تبيّن نوع الفخ. 4) ثق بالتثليث، وافهم الطُّعوم، وابحث عن علامات ثقافية. 5) كرّر قراءة علامات الاتجاه ثم ابحث عن علامة المتابعة. قِس المسافة من العلامة الرئيسية.']
];
var CAT_AR = {};
Y.forEach(function(r){
  BASE_SYMBOLS.push({
    id:'y_' + r[0], glyph:r[1], name:r[2], culture:'Yamashita chart · ' + r[4], era:'WWII-era folklore (unverified)',
    shapes:r[3], tradition:'Yamashita / Code Reader chart', danger: r[7] ? 'caution' : 'none',
    meaning:r[5], trailAction:'Photograph it, record a compass bearing and GPS, and compare with nearby signs. Chart readings are unverified folklore.',
    hazard: r[7] ? WARN : '', tr:{en:r[5], ar:r[6]}
  });
});
})();

/* ---------- freehand shape classifier (offline, no AI service) ---------- */
function classifyDrawing(strokes){
  var found = {};
  var raw = strokes.filter(function(s){ return s.length > 0; });
  if (!raw.length) return found;
  var rx0 = 1e9, ry0 = 1e9, rx1 = -1e9, ry1 = -1e9;
  raw.forEach(function(s){ s.forEach(function(p){ rx0 = Math.min(rx0,p[0]); rx1 = Math.max(rx1,p[0]); ry0 = Math.min(ry0,p[1]); ry1 = Math.max(ry1,p[1]); }); });
  var step = Math.max(rx1 - rx0, ry1 - ry0, 1) * 0.02;
  strokes = raw.map(function(s){   // resample so sparse input and dense input behave the same
    var o = [s[0]];
    for (var i=1;i<s.length;i++){
      var a = s[i-1], b = s[i], n = Math.floor(Math.hypot(b[0]-a[0], b[1]-a[1]) / step);
      for (var k=1;k<=n;k++) o.push([a[0] + (b[0]-a[0])*k/(n+1), a[1] + (b[1]-a[1])*k/(n+1)]);
      o.push(b);
    }
    return o;
  }).filter(function(s){ return s.length > 1 || true; });
  var all = [].concat.apply([], strokes), minx = 1e9, miny = 1e9, maxx = -1e9, maxy = -1e9;
  all.forEach(function(p){ minx = Math.min(minx,p[0]); maxx = Math.max(maxx,p[0]); miny = Math.min(miny,p[1]); maxy = Math.max(maxy,p[1]); });
  var S = Math.max(maxx - minx, maxy - miny, 1);
  function plen(s){ var l = 0; for (var i=1;i<s.length;i++) l += Math.hypot(s[i][0]-s[i-1][0], s[i][1]-s[i-1][1]); return l; }
  function rdp(pts, eps){
    if (pts.length < 3) return pts;
    var a = pts[0], b = pts[pts.length-1], dmax = 0, idx = 0, dx = b[0]-a[0], dy = b[1]-a[1], L = Math.hypot(dx,dy) || 1;
    for (var i=1;i<pts.length-1;i++){
      var d = Math.abs(dy*pts[i][0] - dx*pts[i][1] + b[0]*a[1] - b[1]*a[0]) / L;
      if (d > dmax){ dmax = d; idx = i; }
    }
    if (dmax > eps){ var l = rdp(pts.slice(0, idx+1), eps), r = rdp(pts.slice(idx), eps); return l.slice(0,-1).concat(r); }
    return [a, b];
  }
  function smooth(s){ // keep points at least 4% of the size apart so pen jitter does not add fake turning
    var o = [s[0]], gap = S * 0.04;
    for (var i=1;i<s.length;i++){ var l = o[o.length-1]; if (Math.hypot(s[i][0]-l[0], s[i][1]-l[1]) >= gap) o.push(s[i]); }
    return o;
  }
  function turning(s){ var t = 0; for (var i=2;i<s.length;i++){ var a1 = Math.atan2(s[i-1][1]-s[i-2][1], s[i-1][0]-s[i-2][0]), a2 = Math.atan2(s[i][1]-s[i-1][1], s[i][0]-s[i-1][0]), d = a2 - a1; while (d > Math.PI) d -= 2*Math.PI; while (d < -Math.PI) d += 2*Math.PI; t += d; } return t; }
  function areaOf(s){ var a = 0; for (var i=0;i<s.length;i++){ var p = s[i], q = s[(i+1)%s.length]; a += p[0]*q[1] - q[0]*p[1]; } return a/2; }
  // where do two strokes cross? returns [fractionAlongA, fractionAlongB] or null
  function cross(A, B){
    var la = plen(A), lb = plen(B), ca = 0;
    for (var i=1;i<A.length;i++){
      var seg = Math.hypot(A[i][0]-A[i-1][0], A[i][1]-A[i-1][1]), cb = 0;
      for (var j=1;j<B.length;j++){
        var sb = Math.hypot(B[j][0]-B[j-1][0], B[j][1]-B[j-1][1]);
        var x1=A[i-1][0],y1=A[i-1][1],x2=A[i][0],y2=A[i][1],x3=B[j-1][0],y3=B[j-1][1],x4=B[j][0],y4=B[j][1];
        var den = (x1-x2)*(y3-y4) - (y1-y2)*(x3-x4);
        if (Math.abs(den) > 1e-9){
          var tt = ((x1-x3)*(y3-y4) - (y1-y3)*(x3-x4)) / den, uu = -((x1-x2)*(y1-y3) - (y1-y2)*(x1-x3)) / den;
          if (tt >= 0 && tt <= 1 && uu >= 0 && uu <= 1) return [(ca + tt*seg)/la, (cb + uu*sb)/lb];
        }
        cb += sb;
      }
      ca += seg;
    }
    return null;
  }
  var dots = strokes.filter(function(s){ return plen(s) < S * 0.12; }).length;
  var big = strokes.filter(function(s){ return plen(s) >= S * 0.12; });
  if (dots >= 2) found.dots = 1;
  if (!big.length) return found;
  var multiDone = false;
  if (big.length >= 2){
    if (big.length === 2){
      var X = cross(big[0], big[1]);
      if (X){
        var inA = X[0] > .15 && X[0] < .85, inB = X[1] > .15 && X[1] < .85;
        if (inA && inB){
          var A = big[0], da = Math.atan2(A[A.length-1][1]-A[0][1], A[A.length-1][0]-A[0][0]), c = Math.abs(Math.cos(da));
          if (c > .45 && c < .9){ found.xmark = 1; found.cross = 1; } else { found.cross = 1; found.lattice = 1; }
          multiDone = true;
        } else { found.arrow = 1; found.lines = 1; multiDone = true; }   // head stroke meets the tip of a line
      }
    }
    if (!multiDone){
      var allLines = big.every(function(s){ return rdp(s, S*.06).length === 2; });
      if (big.length >= 4 && allLines){ found.lines = 1; found.lattice = 1; multiDone = true; }
      else if (allLines){ found.lines = 1; multiDone = true; }
    }
    if (multiDone) return found;
  }
  big.forEach(function(s){
    var L = plen(s), ends = Math.hypot(s[0][0]-s[s.length-1][0], s[0][1]-s[s.length-1][1]);
    var turn = turning(smooth(s)), straightness = ends / (L || 1);
    if (Math.abs(turn) > 2*Math.PI*1.2 && straightness < .6){ found.spiral = 1; return; }
    var closed = ends < L * 0.2 && L > S * 0.5;
    var eps = Math.max(S * 0.08, 1), simp;
    if (closed){
      var fi = 0, fd = 0; for (var k=0;k<s.length;k++){ var dk = Math.hypot(s[k][0]-s[0][0], s[k][1]-s[0][1]); if (dk > fd){ fd = dk; fi = k; } }
      var h1 = rdp(s.slice(0, fi+1), eps), h2 = rdp(s.slice(fi), eps);
      simp = h1.slice(0,-1).concat(h2);
    } else simp = rdp(s, eps);
    if (closed){
      var corners = simp.length - 1;
      if (simp.length > 3){ // start point may sit mid-edge: merge when nearly straight
        var q0 = simp[simp.length-2], q1 = simp[0], q2 = simp[1];
        var u = [q1[0]-q0[0], q1[1]-q0[1]], w = [q2[0]-q1[0], q2[1]-q1[1]];
        var cs = (u[0]*w[0] + u[1]*w[1]) / ((Math.hypot(u[0],u[1]) * Math.hypot(w[0],w[1])) || 1);
        if (cs > Math.cos(30*Math.PI/180)) corners--;
      }
      if (corners === 3) found.triangle = 1;
      else if (corners === 4){ found.square = 1; var e = Math.atan2(simp[1][1]-simp[0][1], simp[1][0]-simp[0][0]); if (Math.abs(Math.sin(2*e)) > .7) found.diamond = 1; }
      else found.circle = 1;
      return;
    }
    var inner = simp.length - 2;
    function reversals(ax){
      var h = S * 0.08, dir = 0, ext = s[0][ax], n = 0;
      for (var i=1;i<s.length;i++){
        var v = s[i][ax];
        if (dir >= 0){ if (v > ext) ext = v; else if (ext - v > h){ if (dir === 1) n++; dir = -1; ext = v; } if (dir === 0 && v - s[0][ax] > h) dir = 1; }
        else { if (v < ext) ext = v; else if (v - ext > h){ n++; dir = 1; ext = v; } }
      }
      return n;
    }
    var rev = reversals(1), rev2 = reversals(0);
    if (Math.max(rev, rev2) >= 3){ found.wavy = 1; return; }
    if (inner <= 0 || straightness > .93){ found.lines = 1; return; }
    if (inner === 1){
      var p0 = simp[0], p1 = simp[1], p2 = simp[2], v1 = [p0[0]-p1[0], p0[1]-p1[1]], v2 = [p2[0]-p1[0], p2[1]-p1[1]];
      var ang = Math.acos(Math.max(-1, Math.min(1, (v1[0]*v2[0] + v1[1]*v2[1]) / ((Math.hypot(v1[0],v1[1]) * Math.hypot(v2[0],v2[1])) || 1)))) * 180 / Math.PI;
      if (ang < 75){ found.vee = 1; found.arrow = 1; }
      else if (ang < 115){ found.vee = 1; found.square = 1; }
      else found.arc = 1;
      return;
    }
    if (Math.abs(turn) > Math.PI * 0.6 && inner >= 2 && inner <= 6 && straightness < .75){ found.arc = 1; return; }
    if (inner >= 2 && inner <= 4){ found.lines = 1; found.arrow = 1; return; }
    found.wavy = 1;
  });
  return found;
}
