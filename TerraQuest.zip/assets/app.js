"use strict";
/* TerraQuest app logic. Offline. Uses window.Android (when installed) for share, compass, GPS, print. */

var $ = function(id){ return document.getElementById(id); };
function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
function each(list, fn){ Array.prototype.forEach.call(list, fn); }
var HAS_ANDROID = !!(window.Android);

var LS = {
  get: function(k, d){ try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch(e){ return d; } },
  set: function(k, v){ try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch(e){ return false; } }
};

/* ---------------- language ---------------- */
var lang = LS.get('tq_lang', 'en');
if (!LANGS[lang]) lang = 'en';
function uiLang(){ return I18N[lang] ? lang : 'en'; }
function t(k){ var d = I18N[uiLang()]; return (d && d[k]) || I18N.en[k] || k; }
function shapeName(k){ var n = SHAPE_NAMES[k]; return n ? (n[uiLang()] || n.en) : k; }

/* ---------------- symbols ---------------- */
var custom = LS.get('tq_custom_v1', []);
function allSymbols(){ return BASE_SYMBOLS.concat(custom); }
function symById(id){ var a = allSymbols(); for (var i=0;i<a.length;i++) if (a[i].id === id) return a[i]; return null; }
function symTr(s, l){ return (s.tr && (s.tr[l] || s.tr.en)) || ''; }
function symHasTr(s, l){ return !!(s.tr && s.tr[l]); }

/* ---------------- sharing helpers ---------------- */
function b64utf8(s){ return btoa(unescape(encodeURIComponent(s))); }
function toast(msg, el){ var m = el || $('jMsg'); if (m){ m.textContent = msg; } }

function copyText(text){
  if (HAS_ANDROID && Android.copy){ Android.copy(text); return; }
  if (navigator.clipboard && navigator.clipboard.writeText){ navigator.clipboard.writeText(text).catch(function(){}); }
}
function dataUrlToBlob(u){
  var p = u.split(','), mime = (p[0].match(/:(.*?);/) || [0,'image/jpeg'])[1], bin = atob(p[1]), n = bin.length, a = new Uint8Array(n);
  for (var i=0;i<n;i++) a[i] = bin.charCodeAt(i);
  return new Blob([a], {type: mime});
}
function shareText(text, imgDataUrl){
  if (HAS_ANDROID){
    if (imgDataUrl && Android.shareImage){ Android.shareImage(imgDataUrl, text); return; }
    if (Android.share){ Android.share(text); return; }
  }
  if (navigator.share){
    var data = {text: text};
    try {
      if (imgDataUrl){
        var f = new File([dataUrlToBlob(imgDataUrl)], 'terraquest.jpg', {type:'image/jpeg'});
        if (navigator.canShare && navigator.canShare({files:[f]})) data.files = [f];
      }
    } catch(e){}
    navigator.share(data).catch(function(){});
    return;
  }
  copyText(text);
  alert(t('copied'));
}
function shareFile(name, mime, text){
  if (HAS_ANDROID && Android.shareFile){ Android.shareFile(name, mime, b64utf8(text)); return; }
  var a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], {type: mime}));
  a.download = name; document.body.appendChild(a); a.click(); a.remove();
}
function sendSms(text){
  text = String(text).replace(/\*/g, '');
  if (HAS_ANDROID && Android.sms){ Android.sms('', text); return; }
  window.location.href = 'sms:?&body=' + encodeURIComponent(text);
}
function openMaps(lat, lon, label){
  if (HAS_ANDROID && Android.openMaps){ Android.openMaps(lat, lon, label || ''); return; }
  window.open('https://maps.google.com/?q=' + lat + ',' + lon, '_blank');
}
function mapsLink(g){ return 'https://maps.google.com/?q=' + g.lat.toFixed(6) + ',' + g.lon.toFixed(6); }

/* ---------------- GPS ---------------- */
function getGps(){
  try {
    if (HAS_ANDROID && Android.getLocation){
      var r = Android.getLocation();
      if (r){ var p = r.split(','); return {lat: parseFloat(p[0]), lon: parseFloat(p[1]), acc: Math.round(parseFloat(p[2] || '0'))}; }
    }
  } catch(e){}
  return null;
}
function haversine(a, b){
  var R = 6371000, rad = Math.PI/180, dLat = (b.lat-a.lat)*rad, dLon = (b.lon-a.lon)*rad;
  var h = Math.sin(dLat/2)*Math.sin(dLat/2) + Math.cos(a.lat*rad)*Math.cos(b.lat*rad)*Math.sin(dLon/2)*Math.sin(dLon/2);
  return 2*R*Math.asin(Math.min(1, Math.sqrt(h)));
}
function fmtDist(m){ return m < 1000 ? Math.round(m) + ' m' : (m/1000).toFixed(m < 10000 ? 2 : 1) + ' km'; }

/* ---------------- text builders (what gets shared) ---------------- */
function bearingText(b){ return b ? (Math.round(b.deg) + '° (' + (b.ref === 'true' ? t('true_n') : t('mag_n')) + ')') : ''; }

function symText(s){
  var L = ['*' + s.glyph + '  ' + s.name + '*', s.culture + (s.era ? ' · ' + s.era : ''), ''];
  L.push(t('translation') + ' (' + LANGS[lang] + '):');
  L.push(symTr(s, lang));
  if (lang !== 'en' && !symHasTr(s, lang)) L.push(t('no_lang_note'));
  if (s.meaning) L.push('', t('meaning') + ': ' + s.meaning);
  if (s.trailAction) L.push(t('todo') + ': ' + s.trailAction);
  if (s.hazard) L.push(t('hazard') + ': ' + s.hazard);
  L.push('', t('share_footer'));
  return L.join('\n');
}
function findText(f){
  var s = f.symId ? symById(f.symId) : null;
  var L = [];
  L.push('*' + (f.glyph || '?') + '  ' + (s ? s.name : f.sym) + '*');
  L.push(f.when);
  if (s){
    L.push('', t('translation') + ' (' + LANGS[lang] + '):', symTr(s, lang));
    if (lang !== 'en' && !symHasTr(s, lang)) L.push(t('no_lang_note'));
    if (s.meaning) L.push('', t('meaning') + ': ' + s.meaning);
    if (s.hazard) L.push(t('hazard') + ': ' + s.hazard);
  }
  L.push('');
  if (f.gps) L.push('📍 ' + f.gps.lat.toFixed(6) + ', ' + f.gps.lon.toFixed(6) + (f.gps.acc ? ' (±' + f.gps.acc + ' m)' : ''), mapsLink(f.gps));
  if (f.bearing) L.push('🧭 ' + t('bearing') + ': ' + bearingText(f.bearing));
  if (f.rock) L.push('🪨 ' + t('rock') + ': ' + rockSummary(f.rock));
  if (f.notes) L.push(f.notes);
  L.push('', t('share_footer'));
  return L.join('\n').replace(/\n{3,}/g, '\n\n');
}

/* ================= NAV ================= */
var views = ['lab','scan','sym','rocks','compass','vault','jr'];
var curView = 'lab';
function show(v){
  curView = v;
  views.forEach(function(k){ $('v-'+k).classList.toggle('hidden', k !== v); });
  each(document.querySelectorAll('nav button'), function(b){ b.classList.toggle('on', b.getAttribute('data-v') === v); });
  if (v === 'jr') renderJournal();
  if (v === 'vault' && typeof vaultEnter === 'function') vaultEnter();
  if (v === 'compass' || v === 'scan') compassStart(); else compassStop();
  if (v === 'scan' && typeof scanEnter === 'function') scanEnter();
  if (v !== 'scan' && typeof scanLeave === 'function') scanLeave();
  window.scrollTo(0, 0);
}
each(document.querySelectorAll('nav button'), function(b){ b.onclick = function(){ show(b.getAttribute('data-v')); }; });

/* ================= PHOTO LAB ================= */
var work = null, proc = null, procKey = '', raf = 0;
var ov = {x: 0.5, y: 0.5};
var marks = [], tool = 'move', curMark = null;
var cv = $('cv'), cx = cv.getContext('2d');

$('pickCam').onclick = function(){ $('fileCam').click(); };
$('pickGal').onclick = function(){ $('file').click(); };
$('fileCam').onchange = onPhoto;
$('file').onchange = onPhoto;

function onPhoto(e){
  var f = e.target.files && e.target.files[0];
  if (!f) return;
  var url = URL.createObjectURL(f), im = new Image();
  im.onload = function(){
    setWorkFromImage(im, im.width, im.height);
    URL.revokeObjectURL(url);
    e.target.value = '';
  };
  im.onerror = function(){ alert(t('need_photo')); };
  im.src = url;
}
/* shared by the photo picker and the live scanner's capture button */
function setWorkFromImage(img, iw, ih){
  var max = 1000, s = Math.min(1, max / Math.max(iw, ih));
  work = document.createElement('canvas');
  work.width = Math.round(iw * s); work.height = Math.round(ih * s);
  work.getContext('2d').drawImage(img, 0, 0, work.width, work.height);
  cv.width = work.width; cv.height = work.height;
  ov.x = 0.5; ov.y = 0.5; marks = []; procKey = '';
  $('labBody').classList.remove('hidden');
  $('labSave').classList.remove('hidden');
  schedule();
}

function clamp(v){ return v < 0 ? 0 : (v > 255 ? 255 : v); }

function process(){
  var key = [$('mode').value, $('ang').value, $('str').value, $('con').value, $('bri').value, work.width, work.height].join('|');
  if (proc && key === procKey) return;
  procKey = key;
  var w = work.width, h = work.height, n = w*h;
  var d = work.getContext('2d').getImageData(0, 0, w, h).data;
  var mode = $('mode').value, con = parseInt($('con').value,10)/100, bri = parseInt($('bri').value,10);
  var out = document.createElement('canvas'); out.width = w; out.height = h;
  var octx = out.getContext('2d'), o = octx.createImageData(w, h), od = o.data;
  var i, g = new Float32Array(n);
  for (i=0;i<n;i++) g[i] = 0.299*d[i*4] + 0.587*d[i*4+1] + 0.114*d[i*4+2];

  if (mode === 'orig' || mode === 'invert'){
    for (i=0;i<n;i++){
      for (var c=0;c<3;c++){
        var v = (d[i*4+c]-128)*con+128+bri;
        od[i*4+c] = clamp(mode === 'invert' ? 255-v : v);
      }
      od[i*4+3] = 255;
    }
  } else if (mode === 'gray'){
    for (i=0;i<n;i++){
      var v2 = clamp((g[i]-128)*con+128+bri);
      od[i*4] = od[i*4+1] = od[i*4+2] = v2; od[i*4+3] = 255;
    }
  } else if (mode === 'relief'){
    var a = parseInt($('ang').value,10)*Math.PI/180;
    var dx = Math.round(Math.cos(a)*1.4), dy = Math.round(-Math.sin(a)*1.4);
    if (dx === 0 && dy === 0) dx = 1;
    var k = parseInt($('str').value,10);
    for (var y=0;y<h;y++){
      for (var x=0;x<w;x++){
        var x1=x+dx, y1=y+dy, x2=x-dx, y2=y-dy;
        x1 = x1<0?0:(x1>=w?w-1:x1); x2 = x2<0?0:(x2>=w?w-1:x2);
        y1 = y1<0?0:(y1>=h?h-1:y1); y2 = y2<0?0:(y2>=h?h-1:y2);
        var rv = clamp((128 + (g[y1*w+x1]-g[y2*w+x2])*k - 128)*con + 128 + bri);
        var p = (y*w+x)*4; od[p] = od[p+1] = od[p+2] = rv; od[p+3] = 255;
      }
    }
  } else if (mode === 'edge'){
    var ks = parseInt($('str').value,10)/4;
    for (var y3=0;y3<h;y3++){
      for (var x3=0;x3<w;x3++){
        var xl=x3>0?x3-1:0, xr=x3<w-1?x3+1:w-1, yu=y3>0?y3-1:0, yd=y3<h-1?y3+1:h-1;
        var gx = g[y3*w+xr]-g[y3*w+xl], gy = g[yd*w+x3]-g[yu*w+x3];
        var ev = clamp(255 - Math.sqrt(gx*gx+gy*gy)*ks*con + bri);
        var q = (y3*w+x3)*4; od[q] = od[q+1] = od[q+2] = ev; od[q+3] = 255;
      }
    }
  }
  octx.putImageData(o, 0, 0);
  proc = out;
}

function drawOverlay(c, w, h){
  var s = symById($('ovSym').value);
  var op = parseInt($('ovOp').value,10)/100;
  if (!s || op <= 0) return;
  var size = parseInt($('ovSize').value,10) * (w/500);
  c.save();
  c.translate(ov.x*w, ov.y*h);
  c.rotate(parseInt($('ovRot').value,10)*Math.PI/180);
  c.globalAlpha = op;
  c.font = 'bold ' + size + 'px sans-serif';
  c.textAlign = 'center'; c.textBaseline = 'middle';
  c.lineWidth = Math.max(2, size/18); c.strokeStyle = '#000'; c.strokeText(s.glyph, 0, 0);
  c.fillStyle = '#f0c75e'; c.fillText(s.glyph, 0, 0);
  c.restore();
}
function strokeMark(c, w, h, m, lw, color){
  c.lineWidth = lw; c.strokeStyle = color; c.lineCap = 'round'; c.lineJoin = 'round';
  c.beginPath();
  if (m.type === 'pen'){
    for (var i=0;i<m.pts.length;i++){
      var px = m.pts[i][0]*w, py = m.pts[i][1]*h;
      if (i === 0) c.moveTo(px, py); else c.lineTo(px, py);
    }
    if (m.pts.length === 1) c.lineTo(m.pts[0][0]*w+0.1, m.pts[0][1]*h);
  } else if (m.type === 'arrow'){
    var ax = m.a[0]*w, ay = m.a[1]*h, bx = m.b[0]*w, by = m.b[1]*h;
    var ang = Math.atan2(by-ay, bx-ax), hl = Math.max(14, w/28);
    c.moveTo(ax, ay); c.lineTo(bx, by);
    c.moveTo(bx - hl*Math.cos(ang-0.45), by - hl*Math.sin(ang-0.45)); c.lineTo(bx, by);
    c.lineTo(bx - hl*Math.cos(ang+0.45), by - hl*Math.sin(ang+0.45));
  } else if (m.type === 'circle'){
    var r = Math.sqrt(Math.pow((m.b[0]-m.a[0])*w, 2) + Math.pow((m.b[1]-m.a[1])*h, 2));
    c.arc(m.a[0]*w, m.a[1]*h, Math.max(2, r), 0, Math.PI*2);
  }
  c.stroke();
}
function drawMarks(c, w, h){
  var all = curMark ? marks.concat([curMark]) : marks, lw = Math.max(3, w/170);
  all.forEach(function(m){ strokeMark(c, w, h, m, lw*2.2, '#000'); strokeMark(c, w, h, m, lw, '#ffd23f'); });
}
function paint(c, w, h, src, withOv){
  c.drawImage(src, 0, 0, w, h);
  if (withOv) drawOverlay(c, w, h);
  drawMarks(c, w, h);
}
function draw(){
  if (!work) return;
  process();
  cx.clearRect(0, 0, cv.width, cv.height);
  paint(cx, cv.width, cv.height, proc, true);
  $('angV').textContent = $('ang').value + '°';
  $('strV').textContent = $('str').value;
}
function schedule(){ if (raf) return; raf = requestAnimationFrame(function(){ raf = 0; draw(); }); }
['mode','ang','str','con','bri','ovSym','ovSize','ovRot','ovOp'].forEach(function(id){
  $(id).addEventListener('input', schedule); $(id).addEventListener('change', schedule);
});

function compose(maxSide, view, withOv){
  process();
  var s = Math.min(1, maxSide / Math.max(work.width, work.height));
  var w = Math.round(work.width*s), h = Math.round(work.height*s);
  var c = document.createElement('canvas'); c.width = w; c.height = h;
  paint(c.getContext('2d'), w, h, view === 'orig' ? work : proc, withOv);
  return c;
}

/* pointer: move overlay or draw marks */
function ptOf(e){ var r = cv.getBoundingClientRect(); return [(e.clientX-r.left)/r.width, (e.clientY-r.top)/r.height]; }
var dragging = false;
cv.addEventListener('pointerdown', function(e){
  if (!work) return;
  dragging = true;
  try { cv.setPointerCapture(e.pointerId); } catch(x){}
  var p = ptOf(e);
  if (tool === 'move'){ ov.x = p[0]; ov.y = p[1]; }
  else if (tool === 'pen') curMark = {type:'pen', pts:[p]};
  else curMark = {type:tool, a:p, b:p};
  schedule();
});
cv.addEventListener('pointermove', function(e){
  if (!dragging) return;
  var p = ptOf(e);
  if (tool === 'move'){ ov.x = p[0]; ov.y = p[1]; }
  else if (curMark){ if (curMark.type === 'pen') curMark.pts.push(p); else curMark.b = p; }
  schedule();
});
function endDrag(){
  dragging = false;
  if (curMark){ marks.push(curMark); curMark = null; }
  schedule();
}
cv.addEventListener('pointerup', endDrag);
cv.addEventListener('pointercancel', endDrag);

each($('toolChips').querySelectorAll('[data-tool]'), function(b){
  b.onclick = function(){
    tool = b.getAttribute('data-tool');
    each($('toolChips').querySelectorAll('[data-tool]'), function(x){ x.classList.toggle('on', x === b); });
  };
});
$('undo').onclick = function(){ marks.pop(); schedule(); };
$('clearMarks').onclick = function(){ marks = []; schedule(); };

/* symbol selects + preview */
function fillSymbolSelects(){
  var keepOv = $('ovSym').value, keepSave = $('saveSym').value;
  var opts = allSymbols().map(function(s){ return '<option value="'+esc(s.id)+'">'+esc(s.glyph+'  '+s.name)+'</option>'; }).join('');
  $('ovSym').innerHTML = opts;
  $('saveSym').innerHTML = '<option value="">' + esc(t('unknown')) + '</option>' + opts;
  if (keepOv && symById(keepOv)) $('ovSym').value = keepOv;
  if (keepSave && symById(keepSave)) $('saveSym').value = keepSave;
  renderSymPreview();
}
function renderSymPreview(){
  var s = symById($('saveSym').value);
  if (!s){ $('symPreview').innerHTML = ''; return; }
  $('symPreview').innerHTML = '<div class="tr">' + esc(symTr(s, lang)) + '</div><div class="sub">' + esc(s.meaning || '') + '</div>';
  $('symPreview').setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');
}
$('saveSym').onchange = renderSymPreview;

function currentGpsText(g){ return g ? ('GPS ' + g.lat.toFixed(5) + ', ' + g.lon.toFixed(5)) : ''; }
function buildLabFind(){
  var s = symById($('saveSym').value);
  return {
    symId: s ? s.id : '', sym: s ? s.name : t('unknown'), glyph: s ? s.glyph : '?',
    when: new Date().toLocaleString(), notes: $('saveNotes').value.trim(),
    gps: getGps(), bearing: cmpBearing(true), rock: rockAttach()
  };
}
function updateAttachInfo(){
  var parts = [];
  if (cmp.locked != null) parts.push('🧭 ' + t('locked') + ': ' + bearingText(cmp.locked));
  var r = rockAttach(); if (r) parts.push('🪨 ' + rockSummary(r));
  $('attachInfo').textContent = parts.join('  ·  ');
}

$('saveBtn').onclick = function(){
  if (!work){ $('saveMsg').textContent = t('need_photo'); return; }
  var f = buildLabFind();
  f.id = Date.now();
  f.img = compose(640, $('saveView').value, $('incOv').checked).toDataURL('image/jpeg', 0.72);
  var all = LS.get('tq_finds_v1', []); all.unshift(f);
  if (!LS.set('tq_finds_v1', all)){
    all.shift(); f.img = ''; all.unshift(f);
    if (!LS.set('tq_finds_v1', all)){ $('saveMsg').textContent = t('storage_full'); return; }
  }
  $('saveMsg').textContent = f.gps ? (t('saved_gps') + ' ' + f.gps.lat.toFixed(5) + ', ' + f.gps.lon.toFixed(5)) : t('saved_nogps');
  $('saveNotes').value = '';
  cmp.locked = null; rock = blankRock(); renderRocks(); renderCompassLock(); updateAttachInfo();
};
$('shareImg').onclick = function(){
  if (!work){ $('saveMsg').textContent = t('need_photo'); return; }
  var f = buildLabFind();
  shareText(findText(f), compose(1280, $('saveView').value, $('incOv').checked).toDataURL('image/jpeg', 0.85));
};

/* ================= SYMBOLS ================= */
var picked = {};
function shapeLabel(k){ return (SHAPE_ICONS[k] || '') + ' ' + shapeName(k); }
function renderChips(){
  $('shapeChips').innerHTML = Object.keys(SHAPE_NAMES).map(function(k){
    return '<button class="chip' + (picked[k] ? ' on' : '') + '" data-k="' + k + '">' + esc(shapeLabel(k)) + '</button>';
  }).join('');
  each($('shapeChips').querySelectorAll('.chip'), function(b){
    b.onclick = function(){ var k = b.getAttribute('data-k'); if (picked[k]) delete picked[k]; else picked[k] = 1; renderChips(); renderIdentify(); };
  });
}
function symCard(s, extra){
  var rtl = lang === 'ar' ? ' dir="rtl"' : '';
  var has = symHasTr(s, lang) || lang === 'en';
  return '<div class="card"><div class="sym"><div class="glyph">' + esc(s.glyph) + '</div><div style="flex:1">' +
    '<b class="gold">' + esc(s.name) + '</b><br><span class="tag">' + esc(s.culture) + '</span>' +
    (s.era ? '<span class="tag">' + esc(s.era) + '</span>' : '') + (s.tradition ? '<span class="tag">' + esc(s.tradition) + '</span>' : '') + (s.danger === 'caution' ? '<span class="tag" style="color:#ff9a6a">' + esc(t('danger_caution')) + '</span>' : '') + (s.custom ? '<span class="tag">' + esc(t('custom_tag')) + '</span>' : '') +
    (extra || '') +
    '<div class="row"' + rtl + '><b>' + esc(t('translation')) + ' (' + esc(LANGS[lang]) + ')</b>' + esc(symTr(s, lang)) + (has ? '' : ' <span class="sub">' + esc(t('no_lang_note')) + '</span>') + '</div>' +
    (s.meaning ? '<div class="row"><b>' + esc(t('meaning')) + '</b>' + esc(s.meaning) + '</div>' : '') +
    (s.trailAction ? '<div class="row"><b>' + esc(t('todo')) + '</b>' + esc(s.trailAction) + '</div>' : '') +
    (s.hazard ? '<div class="row hazard"><b>' + esc(t('hazard')) + '</b>' + esc(s.hazard) + '</div>' : '') +
    '<div class="btns"><button class="btn" data-share="' + esc(s.id) + '">' + esc(t('share')) + '</button>' +
    '<button class="btn alt" data-copy="' + esc(s.id) + '">' + esc(t('copy')) + '</button>' +
    '<button class="btn alt" data-sms="' + esc(s.id) + '">' + esc(t('sms_btn')) + '</button>' +
    (s.custom ? '<button class="btn red" data-delsym="' + esc(s.id) + '">' + esc(t('delete')) + '</button>' : '') + '</div>' +
    '</div></div></div>';
}
function wireSymButtons(root){
  each(root.querySelectorAll('[data-share]'), function(b){ b.onclick = function(){ var s = symById(b.getAttribute('data-share')); if (s) shareText(symText(s)); }; });
  each(root.querySelectorAll('[data-copy]'), function(b){ b.onclick = function(){ var s = symById(b.getAttribute('data-copy')); if (s){ copyText(symText(s)); b.textContent = t('copied'); } }; });
  each(root.querySelectorAll('[data-sms]'), function(b){ b.onclick = function(){ var s = symById(b.getAttribute('data-sms')); if (s) sendSms(symText(s)); }; });
  each(root.querySelectorAll('[data-delsym]'), function(b){
    b.onclick = function(){
      if (!confirm(t('confirm_del'))) return;
      var id = b.getAttribute('data-delsym');
      custom = custom.filter(function(x){ return x.id !== id; }); LS.set('tq_custom_v1', custom);
      fillSymbolSelects(); renderAllSymbols();
    };
  });
}
function matchSymbols(pickedMap, limit){
  var sel = Object.keys(pickedMap);
  return allSymbols().map(function(s){
    var hit = (s.shapes || []).filter(function(x){ return pickedMap[x]; }).length;
    var union = (s.shapes || []).length + sel.length - hit;
    return {s: s, score: union ? hit/union : 0, hit: hit};
  }).filter(function(r){ return r.hit > 0; }).sort(function(a,b){ return b.score - a.score; }).slice(0, limit);
}
function renderIdentify(){
  var sel = Object.keys(picked);
  if (!sel.length){ $('idResults').innerHTML = '<div class="sub" style="padding:6px">' + esc(t('pick_some')) + '</div>'; return; }
  var res = matchSymbols(picked, 6);
  if (!res.length){ $('idResults').innerHTML = '<div class="card">' + esc(t('no_match')) + '</div>'; return; }
  $('idResults').innerHTML = res.map(function(r){
    var pct = Math.round(r.score*100);
    return symCard(r.s, '<div class="sub">' + esc(t('match')) + ' ' + pct + '%</div><div class="score"><i style="width:' + pct + '%"></i></div>');
  }).join('') + '<div class="btns"><button class="btn alt" id="idExport">' + esc(t('export_results')) + '</button></div><div class="sub" style="padding:4px 6px">' + esc(t('hint_note')) + '</div>';
  wireSymButtons($('idResults'));
  $('idExport').onclick = function(){
    shareFile('terraquest-results.json', 'application/json', JSON.stringify(res.map(function(r){
      return {name: r.s.name, glyph: r.s.glyph, culture: r.s.culture, match: Math.round(r.score*100), translation: symTr(r.s, lang), meaning: r.s.meaning || '', hazard: r.s.hazard || ''};
    }), null, 2));
  };
}
function renderCatalog(){
  var q = $('q').value.trim().toLowerCase();
  var list = allSymbols().filter(function(s){ return !q || (s.name + ' ' + s.culture + ' ' + (s.meaning || '') + ' ' + s.glyph).toLowerCase().indexOf(q) >= 0; });
  $('catList').innerHTML = list.map(function(s){ return symCard(s); }).join('') || '<div class="sub">—</div>';
  wireSymButtons($('catList'));
}
var addPicked = {};
function renderAddShapes(){
  $('aShapes').innerHTML = Object.keys(SHAPE_NAMES).map(function(k){
    return '<button class="chip' + (addPicked[k] ? ' on' : '') + '" data-k="' + k + '">' + esc(shapeLabel(k)) + '</button>';
  }).join('');
  each($('aShapes').querySelectorAll('.chip'), function(b){
    b.onclick = function(){ var k = b.getAttribute('data-k'); if (addPicked[k]) delete addPicked[k]; else addPicked[k] = 1; renderAddShapes(); };
  });
}
function renderMine(){
  $('myList').innerHTML = custom.map(function(s){ return symCard(s); }).join('');
  wireSymButtons($('myList'));
}
$('aSave').onclick = function(){
  var name = $('aName').value.trim();
  if (!name){ $('aMsg').textContent = t('need_name'); return; }
  var en = $('aTrEn').value.trim(), ar = $('aTrAr').value.trim();
  var s = {
    id: 'my_' + Date.now(), custom: true, glyph: $('aGlyph').value.trim() || '◆', name: name,
    culture: $('aCulture').value.trim() || t('my_culture'), era: '', shapes: Object.keys(addPicked),
    meaning: $('aMeaning').value.trim(), trailAction: $('aTodo').value.trim(), hazard: $('aHazard').value.trim(), tr: {}
  };
  s.tr.en = en || s.meaning || name;
  if (ar) s.tr.ar = ar;
  custom.push(s); LS.set('tq_custom_v1', custom);
  ['aGlyph','aName','aCulture','aMeaning','aTodo','aHazard','aTrEn','aTrAr'].forEach(function(id){ $(id).value = ''; });
  addPicked = {}; renderAddShapes();
  $('aMsg').textContent = '✔ ' + s.name;
  fillSymbolSelects(); renderAllSymbols();
};
function renderAllSymbols(){ renderIdentify(); renderCatalog(); renderMine(); }
$('clearShapes').onclick = function(){ picked = {}; renderChips(); renderIdentify(); };
$('q').oninput = renderCatalog;
each(document.querySelectorAll('[data-sub]'), function(b){
  b.onclick = function(){
    var k = b.getAttribute('data-sub');
    each(document.querySelectorAll('[data-sub]'), function(x){ x.classList.toggle('on', x === b); });
    ['ident','cat','add'].forEach(function(n){ $('sub-'+n).classList.toggle('hidden', n !== k); });
  };
});

/* ================= ROCKS ================= */
var HARD_OPTS = [
  {v:'', en:'Not tested', ar:'لم يُختبر', am:'አልተሞከረም'},
  {v:'0-2.5', en:'Soft: a fingernail scratches it (below 2.5)', ar:'ناعم: الظفر يخدشه (أقل من 2.5)', am:'ለስላሳ፡ ጥፍር ይቧጭረዋል (ከ2.5 በታች)'},
  {v:'2.5-3.5', en:'Coin scratches it, nail does not (2.5 to 3.5)', ar:'العملة تخدشه والظفر لا (2.5 إلى 3.5)', am:'ሳንቲም ይቧጭረዋል፣ ጥፍር አይቧጭረውም (2.5 እስከ 3.5)'},
  {v:'3.5-5.5', en:'Knife scratches it, coin does not (3.5 to 5.5)', am:'ቢላዋ ይቧጭረዋል፣ ሳንቲም አይቧጭረውም (3.5 እስከ 5.5)', ar:'السكين تخدشه والعملة لا (3.5 إلى 5.5)'},
  {v:'5.5-6.5', en:'Scratches glass weakly, a steel file scratches it (5.5 to 6.5)', ar:'يخدش الزجاج قليلاً والمبرد يخدشه (5.5 إلى 6.5)', am:'መስታወትን በጥቂቱ ይቧጭራል፣ የብረት ሞረድ ይቧጭረዋል (5.5 እስከ 6.5)'},
  {v:'6.5-10', en:'Hard: scratches glass and a steel file (above 6.5)', ar:'صلب: يخدش الزجاج والمبرد (أكثر من 6.5)', am:'ጠንካራ፡ መስታወትንና የብረት ሞረድን ይቧጭራል (ከ6.5 በላይ)'}
];
function blankRock(){ return {type:'', mineral:'', color:'', hard:'', streak:'', luster:'', mag:'', fizz:''}; }
var rock = blankRock();
function rockAttach(){
  var any = false; for (var k in rock) if (rock[k]) any = true;
  return any ? JSON.parse(JSON.stringify(rock)) : null;
}
function opt(v, label, cur){ return '<option value="' + esc(v) + '"' + (cur === v ? ' selected' : '') + '>' + esc(label) + '</option>'; }
function sel(id, label, options, cur){ return '<label>' + esc(label) + '</label><select id="' + id + '">' + options.join('') + '</select>'; }
function rockSummary(r){
  var P = [];
  if (r.type){ P.push(t('r_type') + ': ' + ({igneous:t('r_igneous'), sed:t('r_sed'), meta:t('r_meta'), unk:t('r_unk')}[r.type] || r.type).replace(/\s*\(.*\)/, '')); }
  if (r.mineral) P.push(t('r_mineral') + ': ' + r.mineral);
  if (r.color) P.push(t('r_color') + ': ' + r.color);
  if (r.hard){ var h = r.hard.split('-'); P.push(t('r_hard') + ': ' + (h[0] === '0' ? '<' + h[1] : (h[1] === '10' ? '>' + h[0] : h[0] + '–' + h[1]))); }
  if (r.streak) P.push(t('r_streak') + ': ' + t('st_' + r.streak));
  if (r.luster) P.push(t('r_luster') + ': ' + t('l_' + r.luster));
  if (r.mag) P.push(t('r_mag') + ': ' + t(r.mag));
  if (r.fizz) P.push(t('r_fizz') + ': ' + t(r.fizz));
  return P.join('; ');
}
function renderRocks(){
  var u = uiLang();
  var typeOpts = [opt('', t('untested'), rock.type), opt('igneous', t('r_igneous'), rock.type), opt('sed', t('r_sed'), rock.type), opt('meta', t('r_meta'), rock.type), opt('unk', t('r_unk'), rock.type)];
  var hardOpts = HARD_OPTS.map(function(h){ return opt(h.v, h[u] || h.en, rock.hard); });
  var streakOpts = [opt('', t('untested'), rock.streak)].concat(['white','gray','black','red','yellow','green'].map(function(k){ return opt(k, t('st_'+k), rock.streak); }));
  var lusterOpts = [opt('', t('untested'), rock.luster)].concat(['metal','vit','pearl','dull'].map(function(k){ return opt(k, t('l_'+k), rock.luster); }));
  var magOpts = [opt('', t('untested'), rock.mag), opt('no', t('no'), rock.mag), opt('weak', t('weak'), rock.mag), opt('yes', t('yes'), rock.mag)];
  var fizzOpts = [opt('', t('untested'), rock.fizz), opt('no', t('no'), rock.fizz), opt('yes', t('yes'), rock.fizz)];
  $('rockForm').innerHTML =
    sel('rType', t('r_type'), typeOpts) +
    '<label>' + esc(t('r_mineral')) + '</label><input type="text" id="rMineral" value="' + esc(rock.mineral) + '">' +
    '<label>' + esc(t('r_color')) + '</label><input type="text" id="rColor" value="' + esc(rock.color) + '">' +
    sel('rHard', t('r_hard'), hardOpts) + sel('rStreak', t('r_streak'), streakOpts) + sel('rLuster', t('r_luster'), lusterOpts) +
    sel('rMag', t('r_mag'), magOpts) + sel('rFizz', t('r_fizz'), fizzOpts);
  $('hardRef').textContent = t('hard_ref');
  var map = {rType:'type', rMineral:'mineral', rColor:'color', rHard:'hard', rStreak:'streak', rLuster:'luster', rMag:'mag', rFizz:'fizz'};
  Object.keys(map).forEach(function(id){
    var fn = function(){ rock[map[id]] = $(id).value; renderRockResults(); updateAttachInfo(); };
    $(id).oninput = fn; $(id).onchange = fn;
  });
  renderRockResults();
}
function renderRockResults(){
  var tested = 0, list = [];
  MINERALS.forEach(function(m){
    var poss = 0, got = 0;
    if (rock.hard){
      var lim = rock.hard.split('-').map(parseFloat); poss += 2;
      got += (m.h[1] >= lim[0] - 0.01 && m.h[0] <= lim[1] + 0.01) ? 2 : -2;
    }
    if (rock.streak){ poss += 2; got += (m.streak === rock.streak) ? 2 : -2; }
    if (rock.luster){ poss += 1; got += (m.luster === rock.luster) ? 1 : -1; }
    if (rock.mag){ poss += 2; got += (m.mag === rock.mag) ? 2 : ((m.mag !== 'no' && rock.mag !== 'no') ? 0 : -2); }
    if (rock.fizz){ poss += 2; got += (m.fizz === rock.fizz) ? 2 : -2; }
    if (poss){ tested = poss; list.push({m: m, pct: Math.max(0, got) / poss, got: got}); }
  });
  if (!tested){ $('rockResults').innerHTML = '<div class="sub">' + esc(t('no_input')) + '</div>'; return; }
  list = list.filter(function(x){ return x.pct > 0; }).sort(function(a,b){ return b.pct - a.pct; }).slice(0, 5);
  $('rockResults').innerHTML = list.length ? list.map(function(x){
    var p = Math.round(x.pct*100);
    return '<div class="row"><b>' + esc(x.m.n) + ' · ' + p + '%</b><div class="score"><i style="width:' + p + '%"></i></div>' + esc(x.m.note) + '</div>';
  }).join('') : '<div class="sub">—</div>';
}
$('rockClear').onclick = function(){ rock = blankRock(); renderRocks(); updateAttachInfo(); };

/* ================= COMPASS ================= */
var cmp = {on: false, timer: 0, mag: null, tru: null, locked: null, ok: null, webH: null, src: ''};
var ccv = $('cmpcv'), cc = ccv.getContext('2d');
function cmpHeading(){
  if (cmp.tru != null) return {deg: cmp.tru, ref: 'true'};
  if (cmp.mag != null) return {deg: cmp.mag, ref: 'mag'};
  return null;
}
function cmpBearing(forSave){ return cmp.locked; }
function onWebOrient(e){
  var h = null;
  if (typeof e.webkitCompassHeading === 'number') h = e.webkitCompassHeading;
  else if (e.absolute && typeof e.alpha === 'number') h = (360 - e.alpha) % 360;
  if (h != null){ cmp.mag = h; cmp.tru = null; }
}
function compassStart(){
  if (cmp.on) return;
  cmp.on = true;
  if (HAS_ANDROID && Android.compassStart){ cmp.src = 'android'; cmp.ok = !!Android.compassStart(); }
  else if (window.DeviceOrientationEvent){
    cmp.src = 'web'; cmp.ok = true;
    window.addEventListener('deviceorientationabsolute', onWebOrient, true);
    window.addEventListener('deviceorientation', onWebOrient, true);
  } else cmp.ok = false;
  cmp.timer = setInterval(compassTick, 150);
  compassTick();
}
function compassStop(){
  if (!cmp.on) return;
  cmp.on = false; clearInterval(cmp.timer);
  if (cmp.src === 'android' && Android.compassStop) Android.compassStop();
  window.removeEventListener('deviceorientationabsolute', onWebOrient, true);
  window.removeEventListener('deviceorientation', onWebOrient, true);
}
function compassTick(){
  if (cmp.src === 'android' && Android.getHeading){
    var r = Android.getHeading();
    if (r){ var p = r.split(','); cmp.mag = parseFloat(p[0]); cmp.tru = p[2] === '1' ? parseFloat(p[1]) : null; }
  }
  drawCompass();
}
var CARD = ['N','NE','E','SE','S','SW','W','NW'];
function drawCompass(){
  var w = ccv.width, h = ccv.height, c = cc, cx0 = w/2, cy0 = h/2, R = w/2 - 14;
  var hd = cmpHeading();
  c.clearRect(0, 0, w, h);
  c.fillStyle = '#0e0c09'; c.beginPath(); c.arc(cx0, cy0, R+10, 0, Math.PI*2); c.fill();
  c.strokeStyle = '#3a3125'; c.lineWidth = 2; c.beginPath(); c.arc(cx0, cy0, R, 0, Math.PI*2); c.stroke();
  var rot = hd ? -hd.deg : 0;
  c.save(); c.translate(cx0, cy0); c.rotate(rot*Math.PI/180);
  for (var a=0; a<360; a+=10){
    var big = a % 90 === 0, len = big ? 16 : (a % 30 === 0 ? 11 : 6);
    c.save(); c.rotate(a*Math.PI/180);
    c.strokeStyle = a === 0 ? '#e0634f' : '#a8997d'; c.lineWidth = big ? 3 : 1.5;
    c.beginPath(); c.moveTo(0, -R); c.lineTo(0, -R+len); c.stroke();
    if (big){
      c.fillStyle = a === 0 ? '#e0634f' : '#f0e6d2'; c.font = 'bold 22px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
      c.fillText(CARD[a/45], 0, -R+34);
    }
    c.restore();
  }
  if (cmp.locked){
    c.save(); c.rotate(cmp.locked.deg*Math.PI/180);
    c.fillStyle = '#7fb069'; c.beginPath(); c.moveTo(0, -R+2); c.lineTo(-9, -R+22); c.lineTo(9, -R+22); c.closePath(); c.fill(); c.restore();
  }
  c.restore();
  c.fillStyle = '#f0c75e'; c.beginPath(); c.moveTo(cx0, 6); c.lineTo(cx0-10, 30); c.lineTo(cx0+10, 30); c.closePath(); c.fill();
  c.fillStyle = '#f0c75e'; c.beginPath(); c.arc(cx0, cy0, 4, 0, Math.PI*2); c.fill();
  if (hd){
    var idx = Math.round(hd.deg/45) % 8;
    $('cmpTxt').textContent = Math.round(hd.deg) + '° ' + CARD[idx];
    $('cmpSub').textContent = hd.ref === 'true' ? t('true_n') : t('mag_n');
  } else {
    $('cmpTxt').textContent = '--';
    $('cmpSub').textContent = cmp.ok === false || cmp.src === '' ? t('no_compass') : t('hold_flat');
  }
}
function renderCompassLock(){
  $('cmpLocked').textContent = cmp.locked ? ('🔒 ' + t('locked') + ': ' + bearingText(cmp.locked)) : '';
  updateAttachInfo();
}
$('cmpLock').onclick = function(){ var h = cmpHeading(); if (!h) return; cmp.locked = {deg: Math.round(h.deg), ref: h.ref}; renderCompassLock(); drawCompass(); };
$('cmpUnlock').onclick = function(){ cmp.locked = null; renderCompassLock(); drawCompass(); };

/* ================= JOURNAL ================= */
var FKEY = 'tq_finds_v1';
function loadFinds(){ return LS.get(FKEY, []); }
var jrView = 'list', selFind = null;

function filteredFinds(){
  var q = $('jq').value.trim().toLowerCase(), flt = $('jFilter').value;
  var list = loadFinds().filter(function(f){
    if (flt && f.symId !== flt && !(flt === '_none' && !f.symId)) return false;
    if (!q) return true;
    return (f.sym + ' ' + (f.notes || '') + ' ' + f.when + ' ' + (f.rock ? rockSummary(f.rock) : '')).toLowerCase().indexOf(q) >= 0;
  });
  if ($('jSort').value === 'near'){
    var me = getGps();
    if (me){
      list.forEach(function(f){ f._d = f.gps ? haversine(me, f.gps) : 1e12; });
      list.sort(function(a,b){ return a._d - b._d; });
    }
  }
  return list;
}
function fillFilter(){
  var keep = $('jFilter').value, seen = {}, opts = ['<option value="">' + esc(t('filter_all')) + '</option>'];
  loadFinds().forEach(function(f){
    var k = f.symId || '_none';
    if (seen[k]) return; seen[k] = 1;
    opts.push('<option value="' + esc(k) + '">' + esc((f.glyph || '?') + ' ' + (f.sym || t('unknown'))) + '</option>');
  });
  $('jFilter').innerHTML = opts.join('');
  if (keep && seen[keep]) $('jFilter').value = keep;
}
function findCard(f, withMap){
  var me = (f._d && f._d < 1e11) ? ' · ' + fmtDist(f._d) + ' ' + t('away') : '';
  return '<div class="card find"><div class="sym"><div class="glyph">' + esc(f.glyph || '?') + '</div><div style="flex:1"><b class="gold">' + esc(f.sym) + '</b>' +
    '<div class="sub">' + esc(f.when) + '</div>' +
    (f.gps ? '<div class="sub">📍 ' + f.gps.lat.toFixed(5) + ', ' + f.gps.lon.toFixed(5) + (f.gps.acc ? ' (±' + f.gps.acc + ' m)' : '') + esc(me) + '</div>' : '<div class="sub">' + esc(t('nogps')) + '</div>') +
    (f.bearing ? '<div class="sub">🧭 ' + esc(bearingText(f.bearing)) + '</div>' : '') +
    (f.rock ? '<div class="sub">🪨 ' + esc(rockSummary(f.rock)) + '</div>' : '') +
    (f.notes ? '<div class="row">' + esc(f.notes) + '</div>' : '') + '</div></div>' +
    (f.img ? '<img src="' + f.img + '" alt="">' : '') +
    '<div class="btns"><button class="btn" data-fs="' + f.id + '">' + esc(t('share_with_photo')) + '</button>' +
    '<button class="btn alt" data-fc="' + f.id + '">' + esc(t('copy')) + '</button>' +
    '<button class="btn alt" data-fsms="' + f.id + '">' + esc(t('sms_btn')) + '</button>' +
    (f.gps ? '<button class="btn alt" data-fm="' + f.id + '">' + esc(t('open_maps')) + '</button>' : '') +
    '<button class="btn red" data-fd="' + f.id + '">' + esc(t('delete')) + '</button></div></div>';
}
function findById(id){ var a = loadFinds(); for (var i=0;i<a.length;i++) if (String(a[i].id) === String(id)) return a[i]; return null; }
function wireFindButtons(root){
  each(root.querySelectorAll('[data-fs]'), function(b){ b.onclick = function(){ var f = findById(b.getAttribute('data-fs')); if (f) shareText(findText(f), f.img || null); }; });
  each(root.querySelectorAll('[data-fc]'), function(b){ b.onclick = function(){ var f = findById(b.getAttribute('data-fc')); if (f){ copyText(findText(f)); toast(t('copied')); } }; });
  each(root.querySelectorAll('[data-fsms]'), function(b){ b.onclick = function(){ var f = findById(b.getAttribute('data-fsms')); if (f) sendSms(findText(f)); }; });
  each(root.querySelectorAll('[data-fm]'), function(b){ b.onclick = function(){ var f = findById(b.getAttribute('data-fm')); if (f && f.gps) openMaps(f.gps.lat, f.gps.lon, f.sym); }; });
  each(root.querySelectorAll('[data-fd]'), function(b){
    b.onclick = function(){
      if (!confirm(t('confirm_del'))) return;
      var id = b.getAttribute('data-fd');
      LS.set(FKEY, loadFinds().filter(function(x){ return String(x.id) !== String(id); }));
      selFind = null; renderJournal();
    };
  });
}
function renderJournal(){
  fillFilter();
  var list = filteredFinds();
  if (jrView === 'list'){
    $('jr-list').innerHTML = list.length ? list.map(function(f){ return findCard(f); }).join('') : '<div class="card sub">' + esc(t('no_finds')) + '</div>';
    wireFindButtons($('jr-list'));
  } else {
    drawMap(list);
  }
}
each(document.querySelectorAll('[data-jv]'), function(b){
  b.onclick = function(){
    jrView = b.getAttribute('data-jv');
    each(document.querySelectorAll('[data-jv]'), function(x){ x.classList.toggle('on', x === b); });
    $('jr-list').classList.toggle('hidden', jrView !== 'list');
    $('jr-map').classList.toggle('hidden', jrView !== 'map');
    renderJournal();
  };
});
['jq','jFilter','jSort'].forEach(function(id){ $(id).addEventListener('input', renderJournal); $(id).addEventListener('change', renderJournal); });

/* ---- offline map: plot of finds ---- */
var mapPts = [], mapState = null;
function niceDist(m){
  var steps = [1,2,5,10,20,50,100,200,500,1000,2000,5000,10000,20000,50000,100000];
  for (var i=0;i<steps.length;i++) if (steps[i] >= m) return steps[i];
  return steps[steps.length-1];
}
function drawMap(list){
  var cvm = $('mapcv'), c = cvm.getContext('2d'), W = cvm.width, H = cvm.height, pad = 50;
  var pts = list.filter(function(f){ return f.gps; });
  var tp = (typeof trackPoints === 'function') ? trackPoints() : [];
  var me = getGps();
  c.fillStyle = '#0e0c09'; c.fillRect(0, 0, W, H);
  mapPts = [];
  if (!pts.length && !tp.length){
    c.fillStyle = '#a8997d'; c.font = '22px sans-serif'; c.textAlign = 'center'; c.fillText(t('map_empty'), W/2, H/2);
    $('mapHint').textContent = ''; $('mapInfo').innerHTML = ''; return;
  }
  var all = pts.map(function(f){ return f.gps; }).concat(tp); if (me) all = all.concat([me]);
  var minLat = Math.min.apply(null, all.map(function(g){ return g.lat; })), maxLat = Math.max.apply(null, all.map(function(g){ return g.lat; }));
  var minLon = Math.min.apply(null, all.map(function(g){ return g.lon; })), maxLon = Math.max.apply(null, all.map(function(g){ return g.lon; }));
  var midLat = (minLat + maxLat)/2, kx = Math.cos(midLat*Math.PI/180), mPerDeg = 111320;
  var spanX = Math.max((maxLon - minLon) * kx * mPerDeg, 120), spanY = Math.max((maxLat - minLat) * mPerDeg, 120);
  var scale = Math.min((W - 2*pad)/spanX, (H - 2*pad)/spanY);
  var cxm = (minLon + maxLon)/2, cym = (minLat + maxLat)/2;
  function proj(g){ return [W/2 + (g.lon - cxm) * kx * mPerDeg * scale, H/2 - (g.lat - cym) * mPerDeg * scale]; }
  c.strokeStyle = '#201b14'; c.lineWidth = 1;
  for (var gx = 0; gx <= W; gx += 80){ c.beginPath(); c.moveTo(gx, 0); c.lineTo(gx, H); c.stroke(); }
  for (var gy = 0; gy <= H; gy += 80){ c.beginPath(); c.moveTo(0, gy); c.lineTo(W, gy); c.stroke(); }
  if (tp.length > 1){
    c.strokeStyle = '#4aa3ff'; c.lineWidth = 3; c.lineJoin = 'round'; c.beginPath();
    tp.forEach(function(g, i){ var q = proj(g); if (i === 0) c.moveTo(q[0], q[1]); else c.lineTo(q[0], q[1]); });
    c.stroke();
  }
  var bar = niceDist(90 / scale), barPx = bar * scale;
  c.strokeStyle = '#f0e6d2'; c.lineWidth = 3; c.beginPath(); c.moveTo(20, H-24); c.lineTo(20+barPx, H-24); c.stroke();
  c.fillStyle = '#f0e6d2'; c.font = '16px sans-serif'; c.textAlign = 'left'; c.fillText(bar >= 1000 ? (bar/1000) + ' km' : bar + ' m', 20, H-32);
  c.fillStyle = '#e0634f'; c.beginPath(); c.moveTo(W-30, 14); c.lineTo(W-40, 40); c.lineTo(W-20, 40); c.closePath(); c.fill();
  c.fillStyle = '#f0e6d2'; c.textAlign = 'center'; c.fillText('N', W-30, 60);
  if (me){
    var mp = proj(me); c.fillStyle = '#4aa3ff'; c.beginPath(); c.arc(mp[0], mp[1], 9, 0, Math.PI*2); c.fill();
    c.fillStyle = '#4aa3ff'; c.textAlign = 'left'; c.fillText(t('map_you'), mp[0]+13, mp[1]+5);
  }
  pts.forEach(function(f){
    var p = proj(f.gps), sel = selFind && String(selFind) === String(f.id);
    mapPts.push({x: p[0], y: p[1], id: f.id});
    c.fillStyle = sel ? '#ffffff' : '#f0c75e'; c.strokeStyle = '#000'; c.lineWidth = 3;
    c.beginPath(); c.arc(p[0], p[1], sel ? 13 : 10, 0, Math.PI*2); c.fill(); c.stroke();
    c.fillStyle = '#000'; c.font = 'bold 14px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
    c.fillText((f.glyph || '?').charAt(0), p[0], p[1]+1);
    c.textBaseline = 'alphabetic';
  });
  $('mapHint').textContent = t('map_tap') + ' (' + pts.length + ')';
  var f = selFind ? findById(selFind) : null;
  $('mapInfo').innerHTML = f ? findCard(f) : '';
  if (f) wireFindButtons($('mapInfo'));
}
$('mapcv').addEventListener('click', function(e){
  var r = this.getBoundingClientRect(), sx = this.width / r.width, sy = this.height / r.height;
  var x = (e.clientX - r.left) * sx, y = (e.clientY - r.top) * sy, best = null, bd = 1e9;
  mapPts.forEach(function(p){ var d = Math.hypot(p.x - x, p.y - y); if (d < bd){ bd = d; best = p; } });
  if (best && bd < 34){ selFind = best.id; renderJournal(); }
});
$('shareMap').onclick = function(){
  var list = filteredFinds().filter(function(f){ return f.gps; });
  if (jrView !== 'map') return;
  var txt = list.map(function(f){ return (f.glyph || '?') + ' ' + f.sym + ' — ' + f.gps.lat.toFixed(6) + ', ' + f.gps.lon.toFixed(6) + ' ' + mapsLink(f.gps); }).join('\n');
  shareText(t('report_title') + '\n\n' + txt + '\n\n' + t('share_footer'), $('mapcv').toDataURL('image/jpeg', 0.85));
};

/* ---- export / import ---- */
function csvCell(v){ v = String(v == null ? '' : v); return /[",\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }
$('exCsv').onclick = function(){
  var rows = [['id','date','symbol','latitude','longitude','accuracy_m','bearing_deg','bearing_ref','rock','notes']];
  filteredFinds().forEach(function(f){
    rows.push([f.id, f.when, f.sym, f.gps ? f.gps.lat : '', f.gps ? f.gps.lon : '', f.gps ? f.gps.acc : '', f.bearing ? f.bearing.deg : '', f.bearing ? f.bearing.ref : '', f.rock ? rockSummary(f.rock) : '', f.notes || '']);
  });
  shareFile('terraquest-finds.csv', 'text/csv', '﻿' + rows.map(function(r){ return r.map(csvCell).join(','); }).join('\r\n'));
};
$('exJson').onclick = function(){
  shareFile('terraquest-backup.json', 'application/json', JSON.stringify({v: 1, finds: loadFinds(), custom: custom}));
};
$('imp').onclick = function(){ $('impFile').click(); };
$('impFile').onchange = function(e){
  var f = e.target.files && e.target.files[0]; if (!f) return;
  var rd = new FileReader();
  rd.onload = function(){
    try {
      var d = JSON.parse(rd.result), have = {}, n = 0, cur = loadFinds();
      cur.forEach(function(x){ have[x.id] = 1; });
      (d.finds || []).forEach(function(x){ if (x && x.id && !have[x.id]){ cur.push(x); n++; } });
      cur.sort(function(a,b){ return b.id - a.id; });
      LS.set(FKEY, cur);
      var hc = {}; custom.forEach(function(x){ hc[x.id] = 1; });
      (d.custom || []).forEach(function(x){ if (x && x.id && !hc[x.id]){ custom.push(x); } });
      LS.set('tq_custom_v1', custom);
      fillSymbolSelects(); renderAllSymbols(); renderJournal();
      toast(t('imported') + ': ' + n);
    } catch(err){ toast('Error: ' + err.message); }
  };
  rd.readAsText(f); e.target.value = '';
};
$('shareAll').onclick = function(){
  var list = filteredFinds();
  if (!list.length){ toast(t('nothing')); return; }
  shareText(t('report_title') + '\n\n' + list.map(findText).join('\n\n———\n\n'));
};
$('exPdf').onclick = function(){
  var list = filteredFinds();
  if (!list.length){ toast(t('nothing')); return; }
  var dir = lang === 'ar' ? 'rtl' : 'ltr';
  var html = '<!doctype html><html dir="' + dir + '"><head><meta charset="utf-8"><style>' +
    'body{font-family:sans-serif;color:#111;margin:18px}h1{font-size:20px}.f{border:1px solid #bbb;border-radius:8px;padding:10px;margin:10px 0;page-break-inside:avoid}' +
    '.f img{max-width:100%;max-height:300px;margin-top:6px}.m{color:#555;font-size:12px;white-space:pre-wrap}</style></head><body><h1>' + esc(t('report_title')) + '</h1><div class="m">' + esc(new Date().toLocaleString()) + ' · ' + list.length + '</div>' +
    list.map(function(f){
      return '<div class="f"><b>' + esc((f.glyph || '?') + '  ' + f.sym) + '</b><div class="m">' + esc(findText(f)) + '</div>' + (f.img ? '<img src="' + f.img + '">' : '') + '</div>';
    }).join('') + '</body></html>';
  if (HAS_ANDROID && Android.printHtml){ Android.printHtml(html, 'TerraQuest-report'); return; }
  var w = window.open('', '_blank'); if (w){ w.document.write(html); w.document.close(); setTimeout(function(){ w.print(); }, 400); }
};

/* ================= LANGUAGE / INIT ================= */
function applyLang(){
  var u = uiLang();
  document.documentElement.lang = u;
  document.documentElement.dir = u === 'ar' ? 'rtl' : 'ltr';
  each(document.querySelectorAll('[data-i]'), function(el){ el.textContent = t(el.getAttribute('data-i')); });
  each(document.querySelectorAll('[data-ph]'), function(el){ el.placeholder = t(el.getAttribute('data-ph')); });
  fillSymbolSelects(); renderChips(); renderAddShapes(); renderAllSymbols(); renderRocks();
  renderCompassLock(); drawCompass(); renderJournal(); updateAttachInfo();
  if (typeof scanRender === 'function') scanRender();
  if (typeof extrasRender === 'function') extrasRender();
  if (typeof vaultRender === 'function') vaultRender();
}
$('lang').innerHTML = Object.keys(LANGS).map(function(k){ return '<option value="' + k + '">' + LANGS[k] + '</option>'; }).join('');
$('lang').value = lang;
$('lang').onchange = function(){ lang = $('lang').value; LS.set('tq_lang', lang); applyLang(); };
window.addEventListener('pagehide', compassStop);
applyLang();
