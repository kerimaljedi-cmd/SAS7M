"use strict";
/* coords.js - finds map coordinates inside scanned text.
   parseCoords(text, ref) -> {lat, lon, kind} or null.   kind: geo | url | dms | dec | plus
   ref = {lat, lon} (optional) is used only to complete short Plus Codes like "WC8+R9". */
var Coords = (function(){
  var OLC = '23456789CFGHJMPQRVWX';
  var PAIR_RES = [20, 1, 0.05, 0.0025, 0.000125];

  function plusDecode(code){
    code = String(code).toUpperCase().replace('+', '');
    var lat = -90, lon = -180, n = Math.min(code.length, 10), i;
    if (code.length < 8 || code.length % 2 === 1 && code.length < 10) return null;
    for (i = 0; i < n; i += 2){
      var a = OLC.indexOf(code[i]), b = OLC.indexOf(code[i + 1]);
      if (a < 0 || b < 0) return null;
      lat += a * PAIR_RES[i / 2]; lon += b * PAIR_RES[i / 2];
    }
    var size = PAIR_RES[Math.floor(n / 2) - 1], latSize = size, lonSize = size;
    if (code.length > 10){
      var latP = 0.000125, lonP = 0.000125;
      for (i = 10; i < code.length; i++){
        var d = OLC.indexOf(code[i]); if (d < 0) return null;
        latP /= 5; lonP /= 4;
        lat += Math.floor(d / 4) * latP; lon += (d % 4) * lonP;
        latSize = latP; lonSize = lonP;
      }
    }
    var r = {lat: lat + latSize / 2, lon: lon + lonSize / 2};
    return (r.lat >= -90 && r.lat <= 90 && r.lon >= -180 && r.lon <= 180) ? r : null;
  }
  function plusEncode(lat, lon){
    lat = Math.min(90, Math.max(-90, lat)) + 90; lon = ((lon + 180) % 360 + 360) % 360;
    var code = '', i;
    for (i = 0; i < 5; i++){
      var res = PAIR_RES[i], a = Math.min(19, Math.floor(lat / res + 1e-9)), b = Math.min(19, Math.floor(lon / res + 1e-9));
      code += OLC[a] + OLC[b]; lat -= a * res; lon -= b * res;
    }
    return code;
  }
  /* short code ("WC8+R9") + reference location -> full coordinates */
  function plusRecover(code, ref){
    code = String(code).toUpperCase();
    var plus = code.indexOf('+'), before = plus < 0 ? code.length : plus;
    if (before >= 8) return plusDecode(code);
    var pad = 8 - before, prefix = plusEncode(ref.lat, ref.lon).slice(0, pad);
    var full = plusDecode(prefix + code);
    if (!full) return null;
    var res = Math.pow(20, 2 - pad / 2);                 // size in degrees of the dropped prefix area
    var best = null, bestD = 1e9;
    for (var ka = -1; ka <= 1; ka++) for (var ko = -1; ko <= 1; ko++){
      var la = full.lat + ka * res, lo = full.lon + ko * res;
      if (la < -90 || la > 90) continue;
      lo = ((lo + 180) % 360 + 360) % 360 - 180;
      var dl = Math.abs(lo - ref.lon); if (dl > 180) dl = 360 - dl;
      var dist = Math.abs(la - ref.lat) + dl;
      if (dist < bestD){ bestD = dist; best = {lat: la, lon: lo}; }
    }
    full = best;
    return full;
  }

  function ok(lat, lon){ return isFinite(lat) && isFinite(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180; }
  function dmsToDeg(d, m, s, hemi){
    var v = parseFloat(d) + parseFloat(m || 0) / 60 + parseFloat(s || 0) / 3600;
    return /[SW]/i.test(hemi) ? -v : v;
  }

  function parseCoords(text, ref){
    if (!text) return null;
    var raw = String(text), s = raw, m;
    try { s = decodeURIComponent(raw.replace(/\+/g, '%2B')); } catch (e) { s = raw; }
    s = s.replace(/\s+/g, ' ').trim();

    // geo: URI
    m = s.match(/^geo:\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)/i);
    if (m && ok(+m[1], +m[2])) return {lat: +m[1], lon: +m[2], kind: 'geo'};

    // map links
    if (/https?:\/\//i.test(s) || /(^|\W)(maps|goo\.gl|osm|openstreetmap)/i.test(s)){
      m = s.match(/@(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)/) ||
          s.match(/[?&#](?:q|ll|query|destination|center|sll|daddr|mlat)=(-?\d+(?:\.\d+)?)[,; ]+(-?\d+(?:\.\d+)?)/i) ||
          s.match(/!3d(-?\d+(?:\.\d+)?)!4d(-?\d+(?:\.\d+)?)/) ||
          s.match(/#map=\d+\/(-?\d+(?:\.\d+)?)\/(-?\d+(?:\.\d+)?)/) ||
          s.match(/mlat=(-?\d+(?:\.\d+)?)&mlon=(-?\d+(?:\.\d+)?)/);
      if (m && ok(+m[1], +m[2])) return {lat: +m[1], lon: +m[2], kind: 'url'};
    }

    // degrees minutes seconds with hemisphere letters, e.g. 9°1'48"N 38°44'24"E
    var re = /(\d{1,3})\s*[°ºd:]\s*(\d{1,2})\s*['′m:]\s*(\d{1,2}(?:\.\d+)?)\s*(?:["″s]|'')?\s*([NSEW])/gi, parts = [];
    while ((m = re.exec(s)) !== null) parts.push(m);
    if (parts.length >= 2){
      var la = null, lo = null;
      parts.forEach(function(p){
        var v = dmsToDeg(p[1], p[2], p[3], p[4]);
        if (/[NS]/i.test(p[4]) && la === null) la = v; else if (/[EW]/i.test(p[4]) && lo === null) lo = v;
      });
      if (la !== null && lo !== null && ok(la, lo)) return {lat: la, lon: lo, kind: 'dms'};
    }

    // decimal degrees with hemisphere letters, e.g. 9.03 N, 38.74 E   or   N 9.03 E 38.74
    m = s.match(/(\d{1,3}(?:\.\d+)?)\s*°?\s*([NS])[\s,;]+(\d{1,3}(?:\.\d+)?)\s*°?\s*([EW])/i);
    if (m){
      var a = +m[1] * (/S/i.test(m[2]) ? -1 : 1), b = +m[3] * (/W/i.test(m[4]) ? -1 : 1);
      if (ok(a, b)) return {lat: a, lon: b, kind: 'dec'};
    }
    m = s.match(/([NS])\s*(\d{1,3}(?:\.\d+)?)\s*°?[\s,;]+([EW])\s*(\d{1,3}(?:\.\d+)?)/i);
    if (m){
      var a2 = +m[2] * (/S/i.test(m[1]) ? -1 : 1), b2 = +m[4] * (/W/i.test(m[3]) ? -1 : 1);
      if (ok(a2, b2)) return {lat: a2, lon: b2, kind: 'dec'};
    }

    // Plus Code (open location code)
    m = s.match(/(?:^|[\s,;(])([23456789CFGHJMPQRVWX]{2,8}\+[23456789CFGHJMPQRVWX]{2,7})(?=$|[\s,;)])/i);
    if (m){
      var code = m[1].toUpperCase(), before = code.indexOf('+'), r = null;
      if (before === 8) r = plusDecode(code);
      else if (before < 8 && ref) r = plusRecover(code, ref);
      if (r && ok(r.lat, r.lon)) return {lat: r.lat, lon: r.lon, kind: 'plus', code: code, short: before < 8};
    }

    // plain decimal pair, e.g. 9.0300, 38.7400  (needs at least 2 decimals to avoid random numbers)
    m = s.match(/(-?\d{1,3}\.\d{2,})\s*[,;/ ]\s*(-?\d{1,3}\.\d{2,})/);
    if (m && ok(+m[1], +m[2])) return {lat: +m[1], lon: +m[2], kind: 'dec'};
    return null;
  }

  function bearingTo(a, b){
    var rad = Math.PI / 180, y = Math.sin((b.lon - a.lon) * rad) * Math.cos(b.lat * rad);
    var x = Math.cos(a.lat * rad) * Math.sin(b.lat * rad) - Math.sin(a.lat * rad) * Math.cos(b.lat * rad) * Math.cos((b.lon - a.lon) * rad);
    return (Math.atan2(y, x) / rad + 360) % 360;
  }
  return {parse: parseCoords, plusDecode: plusDecode, plusEncode: plusEncode, plusRecover: plusRecover, bearingTo: bearingTo};
})();
if (typeof module !== 'undefined') module.exports = Coords;
