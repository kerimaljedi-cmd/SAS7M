/* Draw-to-identify: classify freehand strokes into basic shapes and feed the symbol matcher. */
var dStrokes = [], dCur = null;
function drawPaint(){
  var cv = $('drawcv'), c = cv.getContext('2d');
  c.fillStyle = '#e8dfc8'; c.fillRect(0, 0, cv.width, cv.height);
  c.strokeStyle = '#2b2218'; c.lineWidth = 6; c.lineCap = 'round'; c.lineJoin = 'round';
  dStrokes.concat(dCur ? [dCur] : []).forEach(function(s){
    c.beginPath(); s.forEach(function(p, i){ if (i) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); });
    if (s.length === 1){ c.lineTo(s[0][0] + .1, s[0][1]); }
    c.stroke();
  });
}
function applyShapes(found){
  var keys = Object.keys(found);
  if (!keys.length) return false;
  picked = {}; keys.forEach(function(k){ if (SHAPE_NAMES[k]) picked[k] = 1; });
  renderChips(); renderIdentify();
  return true;
}
function drawIdentify(strokes, msgEl){
  var found = classifyDrawing(strokes);
  var keys = Object.keys(found).filter(function(k){ return SHAPE_NAMES[k]; });
  if (!keys.length){ msgEl.textContent = t('draw_none'); return false; }
  msgEl.textContent = t('draw_found') + ' ' + keys.map(function(k){ return shapeLabel(k); }).join(', ');
  applyShapes(found);
  return true;
}
(function(){
  var cv = $('drawcv');
  function pt(e){ var b = cv.getBoundingClientRect(); return [(e.clientX - b.left) * cv.width / b.width, (e.clientY - b.top) * cv.height / b.height]; }
  cv.addEventListener('pointerdown', function(e){ dCur = [pt(e)]; try { cv.setPointerCapture(e.pointerId); } catch(x){} drawPaint(); });
  cv.addEventListener('pointermove', function(e){ if (dCur){ dCur.push(pt(e)); drawPaint(); } });
  var up = function(){ if (dCur){ dStrokes.push(dCur); dCur = null; drawPaint(); } };
  cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
  $('drawClear').onclick = function(){ dStrokes = []; dCur = null; $('drawMsg').textContent = ''; drawPaint(); };
  $('drawGo').onclick = function(){ drawIdentify(dStrokes, $('drawMsg')); $('idResults').scrollIntoView({behavior:'smooth'}); };
  $('marksId').onclick = function(){
    var W = work ? work.width : 1000, H = work ? work.height : 1000;
    var pens = marks.filter(function(m){ return m.type === 'pen'; }).map(function(m){ return m.pts.map(function(p){ return [p[0] * W, p[1] * H]; }); });
    marks.filter(function(m){ return m.type === 'arrow'; }).forEach(function(m){ pens.push([[m.a[0]*W, m.a[1]*H], [m.b[0]*W, m.b[1]*H]]); });
    if (!pens.length){ alert(t('marks_none')); return; }
    show('sym'); var msg = $('drawMsg'); drawIdentify(pens, msg);
  };
  drawPaint();
})();
