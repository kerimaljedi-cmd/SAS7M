"use strict";
/* scan.js - live camera scanner: reads QR / map codes, shows carvings with live relief,
   overlays a catalog symbol, gives instant shape-based translation, and points toward a scanned target.
   Needs app.js (globals), qr.js (QRDec) and coords.js (Coords). */

var scan = {
  on: false, stream: null, raf: 0, lastDraw: 0, lastDec: 0, decCount: 0,
  codes: [], target: null, picked: {}, ref: null, refT: 0, outline: null,
  rawc: null, rctx: null, out: null, gray: null
};
var scv = $('scv'), scx = scv.getContext('2d'), scVid = $('scVid');

function scMsg(s){ $('scMsg').textContent = s || ''; }
function now(){ return (window.performance && performance.now) ? performance.now() : Date.now(); }

/* ---------------- start / stop ---------------- */
function scanStart(){
  if (scan.on) return;
  var md = navigator.mediaDevices;
  if (!md || !md.getUserMedia){ scMsg(t('scan_unsupported')); return; }
  scMsg(t('scan_starting'));
  md.getUserMedia({video: {facingMode: {ideal: 'environment'}, width: {ideal: 1280}, height: {ideal: 720}}, audio: false}).then(function(stream){
    if (curView !== 'scan'){ stream.getTracks().forEach(function(tr){ tr.stop(); }); return; }
    scan.stream = stream; scVid.srcObject = stream;
    var p = scVid.play(); if (p && p.catch) p.catch(function(){});
    scan.on = true; scMsg('');
    if (typeof scanCaps === 'function') scanCaps(stream);
    $('scWrap').classList.remove('hidden'); $('scCap').classList.remove('hidden');
    scanRender();
    scan.raf = requestAnimationFrame(scanLoop);
  }).catch(function(e){
    scMsg(t('scan_denied') + ' (' + ((e && e.name) || e) + ')');
  });
}
function scanStop(){
  if (typeof scanCapsOff === 'function') scanCapsOff();
  if (scan.stream){ scan.stream.getTracks().forEach(function(tr){ tr.stop(); }); }
  scan.stream = null; scan.on = false; scVid.srcObject = null;
  if (scan.raf) cancelAnimationFrame(scan.raf);
  scan.raf = 0; scan.outline = null;
  $('scWrap').classList.add('hidden'); $('scCap').classList.add('hidden');
  scanRender();
}
function scanEnter(){ scanRender(); refreshRef(true); }
function scanLeave(){ if (scan.on) scanStop(); }
function refreshRef(force){
  var t0 = now();
  if (!force && t0 - scan.refT < 2000) return;
  scan.refT = t0;
  var g = getGps();
  if (g) scan.ref = g;
}

/* ---------------- live filters ---------------- */
function liveFilter(src, mode, angDeg){
  var w = src.width, h = src.height, d = src.data, n = w * h, i, x, y;
  if (!scan.out || scan.out.width !== w || scan.out.height !== h){ scan.out = scx.createImageData(w, h); scan.gray = new Uint8Array(n); }
  var g = scan.gray, o = scan.out.data;
  for (i = 0; i < n; i++) g[i] = (d[i*4] * 77 + d[i*4+1] * 150 + d[i*4+2] * 29) >> 8;
  if (mode === 'relief'){
    var a = angDeg * Math.PI / 180, dx = Math.round(Math.cos(a) * 1.4), dy = Math.round(-Math.sin(a) * 1.4);
    if (!dx && !dy) dx = 1;
    for (y = 0; y < h; y++){
      for (x = 0; x < w; x++){
        var x1 = x + dx, x2 = x - dx, y1 = y + dy, y2 = y - dy;
        x1 = x1 < 0 ? 0 : (x1 >= w ? w - 1 : x1); x2 = x2 < 0 ? 0 : (x2 >= w ? w - 1 : x2);
        y1 = y1 < 0 ? 0 : (y1 >= h ? h - 1 : y1); y2 = y2 < 0 ? 0 : (y2 >= h ? h - 1 : y2);
        var v = 128 + (g[y1 * w + x1] - g[y2 * w + x2]) * 5, p = (y * w + x) * 4;
        o[p] = o[p+1] = o[p+2] = v < 0 ? 0 : (v > 255 ? 255 : v); o[p+3] = 255;
      }
    }
  } else {   // edges
    for (y = 0; y < h; y++){
      for (x = 0; x < w; x++){
        var xl = x > 0 ? x - 1 : 0, xr = x < w - 1 ? x + 1 : w - 1, yu = y > 0 ? y - 1 : 0, yd = y < h - 1 ? y + 1 : h - 1;
        var gx = g[y * w + xr] - g[y * w + xl], gy = g[yd * w + x] - g[yu * w + x];
        var e = 255 - Math.sqrt(gx * gx + gy * gy) * 1.6, q = (y * w + x) * 4;
        o[q] = o[q+1] = o[q+2] = e < 0 ? 0 : e; o[q+3] = 255;
      }
    }
  }
  return scan.out;
}

/* ---------------- main loop ---------------- */
function scanLoop(ts){
  if (!scan.on) return;
  scan.raf = requestAnimationFrame(scanLoop);
  if (ts - scan.lastDraw < 80) return;
  scan.lastDraw = ts;
  var vw = scVid.videoWidth, vh = scVid.videoHeight;
  if (!vw || !vh) return;
  var sc = 640 / Math.max(vw, vh), cw = Math.round(vw * sc), ch = Math.round(vh * sc);
  if (scv.width !== cw || scv.height !== ch){ scv.width = cw; scv.height = ch; scan.rawc = null; scan.out = null; }
  if (!scan.rawc){
    scan.rawc = document.createElement('canvas'); scan.rawc.width = cw; scan.rawc.height = ch;
    scan.rctx = scan.rawc.getContext('2d');
  }
  scan.rctx.drawImage(scVid, 0, 0, cw, ch);
  var mode = $('scView').value, decodeNow = (ts - scan.lastDec > 350);
  var img = (mode !== 'normal' || decodeNow) ? scan.rctx.getImageData(0, 0, cw, ch) : null;
  if (mode === 'normal') scx.drawImage(scan.rawc, 0, 0);
  else scx.putImageData(liveFilter(img, mode, parseInt($('scAng').value, 10)), 0, 0);
  if (decodeNow){
    scan.lastDec = ts;
    try {
      var r = QRDec.decode(img.data, cw, ch, (scan.decCount++ % 3) === 0);
      if (r){ scan.outline = {pts: r.corners, t: now()}; addCode(r.text); }
    } catch (e) {}
  }
  refreshRef(false);
  drawHud(cw, ch);
  $('scAngV').textContent = $('scAng').value + '°';
}

function drawHud(w, h){
  var c = scx, f = w / 640, hd = cmpHeading();
  // reticle
  c.save();
  c.strokeStyle = 'rgba(240,199,94,0.9)'; c.lineWidth = 3 * f;
  var bx = w * 0.18, by = h * 0.18, L = 26 * f;
  [[bx, by, 1, 1], [w - bx, by, -1, 1], [bx, h - by, 1, -1], [w - bx, h - by, -1, -1]].forEach(function(k){
    c.beginPath(); c.moveTo(k[0], k[1] + k[3] * L); c.lineTo(k[0], k[1]); c.lineTo(k[0] + k[2] * L, k[1]); c.stroke();
  });
  c.lineWidth = 2 * f; c.beginPath(); c.moveTo(w/2 - 10*f, h/2); c.lineTo(w/2 + 10*f, h/2); c.moveTo(w/2, h/2 - 10*f); c.lineTo(w/2, h/2 + 10*f); c.stroke();
  // overlay symbol
  var s = symById($('scOv').value);
  if (s){
    var size = parseInt($('scOvSize').value, 10) * (w / 500);
    c.globalAlpha = 0.55; c.font = 'bold ' + size + 'px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
    c.lineWidth = Math.max(2, size / 18); c.strokeStyle = '#000'; c.strokeText(s.glyph, w/2, h/2);
    c.fillStyle = '#f0c75e'; c.fillText(s.glyph, w/2, h/2); c.globalAlpha = 1;
  }
  // code outline
  if (scan.outline && now() - scan.outline.t < 1500){
    var p = scan.outline.pts;
    c.strokeStyle = '#7fb069'; c.fillStyle = 'rgba(127,176,105,0.25)'; c.lineWidth = 4 * f;
    c.beginPath(); c.moveTo(p[0][0], p[0][1]); c.lineTo(p[1][0], p[1][1]); c.lineTo(p[3][0], p[3][1]); c.lineTo(p[2][0], p[2][1]); c.closePath(); c.fill(); c.stroke();
  }
  // text HUD
  c.textBaseline = 'top'; c.textAlign = 'left'; c.font = 'bold ' + Math.round(20 * f) + 'px sans-serif';
  var line = hd ? (Math.round(hd.deg) + '° ' + CARD[Math.round(hd.deg / 45) % 8] + (hd.ref === 'true' ? '' : ' (mag)')) : '';
  if (scan.ref) line += (line ? '   ' : '') + '📍 ±' + scan.ref.acc + ' m';
  if (line){ c.fillStyle = 'rgba(0,0,0,0.55)'; c.fillRect(8 * f, 8 * f, c.measureText(line).width + 16 * f, 30 * f); c.fillStyle = '#f0c75e'; c.fillText(line, 16 * f, 12 * f); }
  // target pointer
  if (scan.target && scan.ref){
    var dist = haversine(scan.ref, scan.target), brg = Coords.bearingTo(scan.ref, scan.target);
    var rel = hd ? (brg - hd.deg) : 0, cx0 = w / 2, cy0 = h - 46 * f;
    c.fillStyle = 'rgba(0,0,0,0.55)'; c.fillRect(cx0 - 110 * f, cy0 - 34 * f, 220 * f, 68 * f);
    c.save(); c.translate(cx0 - 70 * f, cy0); c.rotate(rel * Math.PI / 180);
    c.fillStyle = hd ? '#7fb069' : '#a8997d'; c.beginPath(); c.moveTo(0, -24 * f); c.lineTo(-14 * f, 14 * f); c.lineTo(0, 6 * f); c.lineTo(14 * f, 14 * f); c.closePath(); c.fill(); c.restore();
    c.fillStyle = '#f0e6d2'; c.textAlign = 'left'; c.font = 'bold ' + Math.round(22 * f) + 'px sans-serif';
    c.fillText(fmtDist(dist), cx0 - 40 * f, cy0 - 20 * f);
    c.font = Math.round(16 * f) + 'px sans-serif'; c.fillStyle = '#a8997d'; c.fillText(Math.round(brg) + '°', cx0 - 40 * f, cy0 + 8 * f);
  }
  c.restore();
}

/* ---------------- codes ---------------- */
function addCode(text){
  for (var i = 0; i < scan.codes.length; i++){
    if (scan.codes[i].text === text){
      if (i > 0){ var c = scan.codes.splice(i, 1)[0]; scan.codes.unshift(c); renderCodes(); }
      return;
    }
  }
  scan.codes.unshift({id: Date.now() + Math.floor(Math.random() * 1000), text: text, when: new Date().toLocaleTimeString()});
  if (scan.codes.length > 12) scan.codes.pop();
  try { if (navigator.vibrate) navigator.vibrate(60); } catch (e) {}
  renderCodes();
}
function codeText(c, p){
  var L = ['⌗ ' + t('scan_code_name'), c.text];
  if (p) L.push('📍 ' + p.lat.toFixed(6) + ', ' + p.lon.toFixed(6), mapsLink(p));
  L.push('', t('share_footer'));
  return L.join('\n');
}
function renderCodes(){
  var box = $('scCodes');
  if (!scan.codes.length){ box.innerHTML = '<div class="sub" style="margin-top:8px">' + esc(t('scan_nocodes')) + '</div>'; return; }
  box.innerHTML = scan.codes.map(function(c){
    var p = Coords.parse(c.text, scan.ref), kind = '';
    if (p) kind = t('scan_kind_' + p.kind);
    var coord = '', nav = '';
    if (p){
      coord = '<div class="row"><b>' + esc(t('scan_coords')) + '</b>📍 ' + p.lat.toFixed(6) + ', ' + p.lon.toFixed(6) + '</div>';
      nav = scan.ref ? '<div class="sub">🧭 ' + esc(fmtDist(haversine(scan.ref, p))) + ' · ' + Math.round(Coords.bearingTo(scan.ref, p)) + '°</div>'
                     : '<div class="sub">' + esc(t('scan_gps_needed')) + '</div>';
    }
    return '<div class="codecard" data-cid="' + c.id + '">' +
      (kind ? '<span class="tag">' + esc(kind) + '</span>' : '<span class="tag">' + esc(t('scan_text')) + '</span>') +
      '<span class="sub">' + esc(c.when) + '</span><div class="raw">' + esc(c.text) + '</div>' + coord + nav +
      '<div class="btns">' +
      (p ? '<button class="btn" data-act="target">' + esc(t('scan_target_set')) + '</button><button class="btn alt" data-act="maps">' + esc(t('open_maps')) + '</button>' : '') +
      '<button class="btn alt" data-act="save">' + esc(t('scan_save')) + '</button>' +
      '<button class="btn alt" data-act="share">' + esc(t('share')) + '</button>' +
      '<button class="btn alt" data-act="copy">' + esc(t('copy')) + '</button>' +
      '<button class="btn red" data-act="del">' + esc(t('delete')) + '</button></div></div>';
  }).join('');
}
$('scCodes').addEventListener('click', function(e){
  var b = e.target.closest ? e.target.closest('[data-act]') : null;
  if (!b) return;
  var card = b.closest('.codecard'), id = card && card.getAttribute('data-cid'), c = null, i;
  for (i = 0; i < scan.codes.length; i++) if (String(scan.codes[i].id) === String(id)) c = scan.codes[i];
  if (!c) return;
  var p = Coords.parse(c.text, scan.ref), act = b.getAttribute('data-act');
  if (act === 'target' && p){ scan.target = {lat: p.lat, lon: p.lon, label: c.text}; $('scTargetClear').classList.remove('hidden'); scMsg('🎯 ' + p.lat.toFixed(5) + ', ' + p.lon.toFixed(5)); }
  else if (act === 'maps' && p) openMaps(p.lat, p.lon, t('scan_code_name'));
  else if (act === 'save') saveCodeFind(c, p);
  else if (act === 'share') shareText(codeText(c, p));
  else if (act === 'copy'){ copyText(codeText(c, p)); b.textContent = t('copied'); }
  else if (act === 'del'){ scan.codes = scan.codes.filter(function(x){ return x !== c; }); renderCodes(); }
});
$('scTargetClear').onclick = function(){ scan.target = null; $('scTargetClear').classList.add('hidden'); scMsg(''); };

function frameThumb(){
  try {
    if (!scan.on || !scVid.videoWidth) return '';
    var s = Math.min(1, 640 / Math.max(scVid.videoWidth, scVid.videoHeight)), c = document.createElement('canvas');
    c.width = Math.round(scVid.videoWidth * s); c.height = Math.round(scVid.videoHeight * s);
    c.getContext('2d').drawImage(scVid, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', 0.7);
  } catch (e) { return ''; }
}
function saveCodeFind(c, p){
  refreshRef(true);
  var f = {
    id: Date.now(), symId: '', sym: t('scan_code_name'), glyph: '⌗', when: new Date().toLocaleString(), notes: c.text,
    gps: p ? {lat: p.lat, lon: p.lon, acc: 0} : (scan.ref || getGps()), bearing: cmp.locked, rock: null, img: frameThumb()
  };
  var all = LS.get('tq_finds_v1', []); all.unshift(f);
  if (!LS.set('tq_finds_v1', all)){ all.shift(); f.img = ''; all.unshift(f); LS.set('tq_finds_v1', all); }
  scMsg(t('scan_saved'));
}

/* ---------------- capture to the Photo tab ---------------- */
function scanCapture(){
  var vw = scVid.videoWidth, vh = scVid.videoHeight;
  if (!vw || !vh) return;
  var s = Math.min(1, 1600 / Math.max(vw, vh)), c = document.createElement('canvas');
  c.width = Math.round(vw * s); c.height = Math.round(vh * s);
  var x = c.getContext('2d'); x.drawImage(scVid, 0, 0, c.width, c.height);
  var hd = cmpHeading();
  if (hd){ cmp.locked = {deg: Math.round(hd.deg), ref: hd.ref}; }
  try {
    var id = x.getImageData(0, 0, c.width, c.height), r = QRDec.decode(id.data, c.width, c.height, true);
    if (r) addCode(r.text);
  } catch (e) {}
  setWorkFromImage(c, c.width, c.height);
  show('lab');
  renderCompassLock();
}

/* ---------------- read codes from a still photo ---------------- */
function decodeCanvasMulti(cnv){
  var scales = [1, 0.6, 1.6];
  for (var i = 0; i < scales.length; i++){
    var s = scales[i], w = Math.round(cnv.width * s), h = Math.round(cnv.height * s);
    if (w > 2000 || h > 2000) continue;
    var t0 = cnv;
    if (s !== 1){ t0 = document.createElement('canvas'); t0.width = w; t0.height = h; t0.getContext('2d').drawImage(cnv, 0, 0, w, h); }
    var id = t0.getContext('2d').getImageData(0, 0, w, h), r = QRDec.decode(id.data, w, h, true);
    if (r) return r;
  }
  return null;
}
$('readPhotoCodes').onclick = function(){
  if (!work){ alert(t('need_photo')); return; }
  var r = decodeCanvasMulti(work);
  if (!r){ alert(t('scan_none_photo')); return; }
  addCode(r.text);
  show('scan');
};

/* ---------------- shapes -> instant translation ---------------- */
function renderScChips(){
  $('scChips').innerHTML = Object.keys(SHAPE_NAMES).map(function(k){
    return '<button class="chip' + (scan.picked[k] ? ' on' : '') + '" data-k="' + k + '">' + esc(shapeLabel(k)) + '</button>';
  }).join('');
  each($('scChips').querySelectorAll('.chip'), function(b){
    b.onclick = function(){ var k = b.getAttribute('data-k'); if (scan.picked[k]) delete scan.picked[k]; else scan.picked[k] = 1; renderScChips(); renderScMatches(); };
  });
}
function renderScMatches(){
  var res = matchSymbols(scan.picked, 3);
  $('scMatches').innerHTML = res.map(function(r){ return symCard(r.s, '<div class="sub">' + esc(t('match')) + ' ' + Math.round(r.score * 100) + '%</div>'); }).join('');
  wireSymButtons($('scMatches'));
}

/* ---------------- render (also called when the language changes) ---------------- */
function scanRender(){
  var keep = $('scOv').value;
  $('scOv').innerHTML = '<option value="">' + esc(t('scan_none')) + '</option>' +
    allSymbols().map(function(s){ return '<option value="' + esc(s.id) + '">' + esc(s.glyph + '  ' + s.name) + '</option>'; }).join('');
  if (keep && symById(keep)) $('scOv').value = keep;
  $('scGo').textContent = scan.on ? t('scan_stop') : t('scan_start');
  $('scCap').textContent = t('scan_capture');
  $('scTargetClear').classList.toggle('hidden', !scan.target);
  renderScChips(); renderScMatches(); renderCodes();
}
$('scGo').onclick = function(){ if (scan.on) scanStop(); else scanStart(); };
$('scCap').onclick = scanCapture;
document.addEventListener('visibilitychange', function(){ if (document.hidden && scan.on) scanStop(); });
window.addEventListener('pagehide', function(){ if (scan.on) scanStop(); });
scanRender();
