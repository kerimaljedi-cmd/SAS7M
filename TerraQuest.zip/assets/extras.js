/* TerraQuest extras: survey track + GPX, scanner torch/zoom, first-run notice */
var TKEY = 'tq_track_v1', NKEY = 'tq_notice_v1';
var trk = { on: false, timer: null, track: LS.get(TKEY, {pts: [], t0: 0, t1: 0}) };

function trackPoints(){ return trk.track.pts.map(function(p){ return {lat: p[0], lon: p[1]}; }); }
function trkDist(){
  var d = 0, p = trk.track.pts;
  for (var i = 1; i < p.length; i++) d += haversine({lat:p[i-1][0],lon:p[i-1][1]}, {lat:p[i][0],lon:p[i][1]});
  return d;
}
function trkSample(){
  var g = getGps(); if (!g || isNaN(g.lat)) return;
  var p = trk.track.pts, last = p[p.length-1];
  if (last && haversine({lat:last[0],lon:last[1]}, g) < 3) return;   // ignore GPS jitter
  p.push([+g.lat.toFixed(6), +g.lon.toFixed(6), Date.now()]);
  trk.track.t1 = Date.now();
  LS.set(TKEY, trk.track);
  trkRender();
}
function trkToggle(){
  if (trk.on){
    trk.on = false; clearInterval(trk.timer);
    if (HAS_ANDROID){ try { Android.locationStop(); Android.keepAwake(false); } catch(e){} }
  } else {
    trk.on = true;
    if (!trk.track.pts.length) trk.track.t0 = Date.now();
    if (HAS_ANDROID){ try { Android.locationStart(); Android.keepAwake(true); } catch(e){} }
    trkSample(); trk.timer = setInterval(trkSample, 5000);
  }
  trkRender();
}
function trkRender(){
  var b = $('trkGo'), i = $('trkInfo'); if (!b || !i) return;
  b.textContent = trk.on ? t('track_stop') : t('track_start');
  var n = trk.track.pts.length;
  i.textContent = (trk.on ? t('track_rec') + ' ' : '') + (n
    ? t('track_info').replace('{n}', n).replace('{d}', fmtDist(trkDist())).replace('{m}', Math.round(((trk.on ? Date.now() : trk.track.t1) - trk.track.t0) / 60000))
    : t('track_none'));
  if ($('mapcv') && !$('mapcv').closest('.hidden') && typeof renderJournal === 'function' && !trkRender.busy){
    trkRender.busy = true; try { renderJournal(); } catch(e){} trkRender.busy = false;
  }
}
function xmlEsc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function buildGpx(){
  var o = ['<?xml version="1.0" encoding="UTF-8"?>',
    '<gpx version="1.1" creator="TerraQuest" xmlns="http://www.topografix.com/GPX/1/1">'];
  loadFinds().forEach(function(f){
    if (!f.gps) return;
    o.push('<wpt lat="' + f.gps.lat.toFixed(6) + '" lon="' + f.gps.lon.toFixed(6) + '"><name>' +
      xmlEsc(f.sym || 'Find') + '</name>' + (f.notes ? '<desc>' + xmlEsc(f.notes) + '</desc>' : '') + '</wpt>');
  });
  var p = trk.track.pts;
  if (p.length){
    o.push('<trk><name>TerraQuest survey</name><trkseg>');
    p.forEach(function(q){
      o.push('<trkpt lat="' + q[0] + '" lon="' + q[1] + '"><time>' + new Date(q[2]).toISOString() + '</time></trkpt>');
    });
    o.push('</trkseg></trk>');
  }
  o.push('</gpx>');
  return o.join('\n');
}
function trkGpx(){
  var hasW = loadFinds().some(function(f){ return f.gps; });
  if (!hasW && !trk.track.pts.length){ alert(t('gpx_none')); return; }
  shareFile('terraquest-' + new Date().toISOString().slice(0,10) + '.gpx', 'application/gpx+xml', buildGpx());
}
function trkClear(){
  if (trk.on) trkToggle();
  trk.track = {pts: [], t0: 0, t1: 0}; LS.set(TKEY, trk.track); trkRender();
}

/* scanner torch + zoom, only shown when the camera exposes them */
var capTrack = null, torchOn = false;
function scanCaps(stream){
  try {
    capTrack = stream.getVideoTracks()[0];
    var c = capTrack.getCapabilities ? capTrack.getCapabilities() : {};
    if (c.torch) $('scTorch').classList.remove('hidden');
    if (c.zoom){
      $('scZoom').min = c.zoom.min; $('scZoom').max = Math.min(c.zoom.max, 8); $('scZoom').step = c.zoom.step || 0.1;
      $('scZoom').value = c.zoom.min;
      $('scZoom').classList.remove('hidden'); $('scZoomL').classList.remove('hidden');
    }
  } catch(e){}
  if (HAS_ANDROID){ try { Android.keepAwake(true); } catch(e){} }
}
function scanCapsOff(){
  capTrack = null; torchOn = false;
  ['scTorch','scZoom','scZoomL'].forEach(function(id){ if ($(id)) $(id).classList.add('hidden'); });
  if (HAS_ANDROID && !trk.on){ try { Android.keepAwake(false); } catch(e){} }
}

function extrasRender(){
  trkRender();
  var tb = $('scTorch'); if (tb) tb.textContent = t('torch');
}

function noticeShow(){ $('notice').classList.remove('hidden'); }
function extrasInit(){
  $('trkGo').onclick = trkToggle; $('trkClear').onclick = trkClear; $('trkGpx').onclick = trkGpx;
  $('scTorch').onclick = function(){
    if (!capTrack) return; torchOn = !torchOn;
    capTrack.applyConstraints({advanced: [{torch: torchOn}]}).catch(function(){ torchOn = false; });
  };
  $('scZoom').oninput = function(){
    if (capTrack) capTrack.applyConstraints({advanced: [{zoom: parseFloat(this.value)}]}).catch(function(){});
  };
  $('aboutBtn').onclick = noticeShow;
  $('noticeOk').onclick = function(){ $('notice').classList.add('hidden'); try { localStorage.setItem(NKEY, '1'); } catch(e){} };
  var seen = false; try { seen = localStorage.getItem(NKEY) === '1'; } catch(e){}
  if (!seen) noticeShow();
  extrasRender();
}
extrasInit();
