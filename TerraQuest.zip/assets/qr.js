"use strict";
/* qr.js - small offline QR code reader (no dependencies).
   QRDec.decode(rgba, width, height, tryInverted) -> {text, version, ecl, corners:[[x,y]x4]} or null
   Supports versions 1-40, error correction (Reed-Solomon), numeric / alphanumeric / byte / ECI modes. */
var QRDec = (function(){

  /* ---------- GF(256) ---------- */
  var EXP = new Uint8Array(512), LOG = new Uint8Array(256);
  (function(){
    var x = 1, i;
    for (i = 0; i < 255; i++){ EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 256) x ^= 0x11d; }
    for (i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
  })();
  function gmul(a, b){ return (a && b) ? EXP[LOG[a] + LOG[b]] : 0; }
  function ginv(a){ return EXP[255 - LOG[a]]; }
  function gpow(a, k){ return a ? EXP[(LOG[a] * k) % 255] : 0; }

  /* Reed-Solomon: corrects msg (data then EC codewords) in place. Returns true if the block is valid afterwards. */
  function rsCorrect(msg, nsym){
    var n = msg.length, S = [], any = false, i, j;
    for (j = 0; j < nsym; j++){
      var s = 0;
      for (i = 0; i < n; i++) s = gmul(s, EXP[j]) ^ msg[i];
      S.push(s); if (s) any = true;
    }
    if (!any) return true;
    var C = [1], B = [1], L = 0, m = 1, b = 1;
    for (var nn = 0; nn < nsym; nn++){
      var d = S[nn];
      for (i = 1; i <= L; i++) d ^= gmul(C[i] || 0, S[nn - i]);
      if (d === 0){ m++; continue; }
      var coef = gmul(d, ginv(b)), T = C.slice();
      while (C.length < B.length + m) C.push(0);
      for (i = 0; i < B.length; i++) C[i + m] ^= gmul(coef, B[i]);
      if (2 * L <= nn){ L = nn + 1 - L; B = T; b = d; m = 1; } else { m++; }
    }
    if (L * 2 > nsym) return false;
    while (C.length > L + 1 && C[C.length - 1] === 0) C.pop();
    var errs = [];
    for (var p = 0; p < n; p++){
      var xinv = EXP[(255 - (p % 255)) % 255], v = 0, xp = 1;
      for (i = 0; i < C.length; i++){ v ^= gmul(C[i], xp); xp = gmul(xp, xinv); }
      if (v === 0) errs.push(p);
    }
    if (errs.length !== L) return false;
    var omega = [];
    for (i = 0; i < nsym; i++) omega.push(0);
    for (i = 0; i < nsym; i++) for (j = 0; j < C.length && i + j < nsym; j++) omega[i + j] ^= gmul(S[i], C[j]);
    for (var e = 0; e < errs.length; e++){
      var pos = errs[e], X = EXP[pos % 255], Xinv = EXP[(255 - (pos % 255)) % 255];
      var om = 0, xp2 = 1;
      for (var k = 0; k < nsym; k++){ om ^= gmul(omega[k], xp2); xp2 = gmul(xp2, Xinv); }
      var dl = 0;
      for (i = 1; i < C.length; i += 2) dl ^= gmul(C[i], gpow(Xinv, i - 1));
      if (dl === 0) return false;
      var mag = gmul(X, gmul(om, ginv(dl)));
      msg[n - 1 - pos] ^= mag;
    }
    for (j = 0; j < nsym; j++){
      var s2 = 0;
      for (i = 0; i < n; i++) s2 = gmul(s2, EXP[j]) ^ msg[i];
      if (s2) return false;
    }
    return true;
  }

  /* ---------- QR tables ---------- */
  var ECC_PER_BLOCK = [
    [-1, 7,10,15,20,26,18,20,24,30,18,20,24,26,30,22,24,28,30,28,28,28,28,30,30,26,28,30,30,30,30,30,30,30,30,30,30,30,30,30,30],
    [-1,10,16,26,18,24,16,18,22,22,26,30,22,22,24,24,28,28,26,26,26,26,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28],
    [-1,13,22,18,26,18,24,18,22,20,24,28,26,24,20,30,24,28,28,26,30,28,30,30,30,30,28,30,30,30,30,30,30,30,30,30,30,30,30,30,30],
    [-1,17,28,22,16,22,28,26,26,24,28,24,28,22,24,24,30,28,28,26,28,30,24,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30]
  ];
  var NUM_BLOCKS = [
    [-1,1,1,1,1,1,2,2,2,2,4,4,4,4,4,6,6,6,6,7,8,8,9,9,10,12,12,12,13,14,15,16,17,18,19,19,20,21,22,24,25],
    [-1,1,1,1,2,2,4,4,4,5,5,5,8,9,9,10,10,11,13,14,16,17,17,18,20,21,23,25,26,28,29,31,33,35,37,38,40,43,45,47,49],
    [-1,1,1,2,2,4,4,6,6,8,8,8,10,12,16,12,17,16,18,21,20,23,23,25,27,29,34,34,35,38,40,43,45,48,51,53,56,59,62,65,68],
    [-1,1,1,2,4,4,4,5,6,8,8,11,11,16,16,18,16,19,21,25,25,25,34,30,32,35,37,40,42,45,48,51,54,57,60,63,66,70,74,77,81]
  ];
  var FORMAT_ECL = {1: 0, 0: 1, 3: 2, 2: 3};   // format bits -> index into the tables (L, M, Q, H)

  function alignPositions(v){
    if (v === 1) return [];
    var num = Math.floor(v / 7) + 2, size = v * 4 + 17;
    var step = (v === 32) ? 26 : Math.ceil((size - 13) / (num * 2 - 2)) * 2;
    var res = [6];
    for (var pos = size - 7; res.length < num; pos -= step) res.splice(1, 0, pos);
    return res;
  }
  function rawModules(v){
    var r = (16 * v + 128) * v + 64;
    if (v >= 2){ var na = Math.floor(v / 7) + 2; r -= (25 * na - 10) * na - 55; if (v >= 7) r -= 36; }
    return r;
  }
  function functionMap(v){
    var size = v * 4 + 17, f = new Uint8Array(size * size), x, y;
    for (y = 0; y < size; y++) for (x = 0; x < size; x++){
      if ((x <= 8 && y <= 8) || (x >= size - 8 && y <= 8) || (x <= 8 && y >= size - 8) || x === 6 || y === 6) f[y * size + x] = 1;
    }
    var ap = alignPositions(v), n = ap.length;
    for (var i = 0; i < n; i++) for (var j = 0; j < n; j++){
      if ((i === 0 && j === 0) || (i === 0 && j === n - 1) || (i === n - 1 && j === 0)) continue;
      for (var dy = -2; dy <= 2; dy++) for (var dx = -2; dx <= 2; dx++) f[(ap[j] + dy) * size + ap[i] + dx] = 1;
    }
    if (v >= 7){
      for (y = 0; y < 6; y++) for (x = size - 11; x < size - 8; x++) f[y * size + x] = 1;
      for (x = 0; x < 6; x++) for (y = size - 11; y < size - 8; y++) f[y * size + x] = 1;
    }
    return f;
  }
  var FORMAT_CODES = (function(){
    var arr = [];
    for (var data = 0; data < 32; data++){
      var rem = data;
      for (var i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
      arr.push(((data << 10) | rem) ^ 0x5412);
    }
    return arr;
  })();
  function popcount(x){ var c = 0; while (x){ c += x & 1; x >>>= 1; } return c; }
  function maskBit(mask, x, y){
    switch (mask){
      case 0: return (x + y) % 2 === 0;
      case 1: return y % 2 === 0;
      case 2: return x % 3 === 0;
      case 3: return (x + y) % 3 === 0;
      case 4: return (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0;
      case 5: return (x * y) % 2 + (x * y) % 3 === 0;
      case 6: return ((x * y) % 2 + (x * y) % 3) % 2 === 0;
      default: return ((x + y) % 2 + (x * y) % 3) % 2 === 0;
    }
  }

  /* ---------- image to black/white ---------- */
  function binarize(rgba, w, h){
    var n = w * h, gray = new Uint8Array(n), i;
    for (i = 0; i < n; i++) gray[i] = (rgba[i*4] * 77 + rgba[i*4+1] * 150 + rgba[i*4+2] * 29) >> 8;
    var W = w + 1, integral = new Float64Array(W * (h + 1)), x, y;
    for (y = 0; y < h; y++){
      var rowSum = 0;
      for (x = 0; x < w; x++){
        rowSum += gray[y * w + x];
        integral[(y + 1) * W + x + 1] = integral[y * W + x + 1] + rowSum;
      }
    }
    var r = Math.max(7, Math.round(Math.min(w, h) / 16)), bin = new Uint8Array(n);
    for (y = 0; y < h; y++){
      var y0 = Math.max(0, y - r), y1 = Math.min(h, y + r + 1);
      for (x = 0; x < w; x++){
        var x0 = Math.max(0, x - r), x1 = Math.min(w, x + r + 1);
        var sum = integral[y1 * W + x1] - integral[y0 * W + x1] - integral[y1 * W + x0] + integral[y0 * W + x0];
        var mean = sum / ((x1 - x0) * (y1 - y0));
        bin[y * w + x] = gray[y * w + x] < mean - 7 ? 1 : 0;
      }
    }
    return bin;
  }

  /* ---------- finder patterns ---------- */
  function ratioOk(c){
    var total = c[0] + c[1] + c[2] + c[3] + c[4];
    if (total < 7) return 0;
    var mod = total / 7, tol = mod * 0.6;
    if (Math.abs(c[0] - mod) > tol || Math.abs(c[1] - mod) > tol || Math.abs(c[3] - mod) > tol || Math.abs(c[4] - mod) > tol) return 0;
    if (Math.abs(c[2] - 3 * mod) > mod * 1.5) return 0;
    return mod;
  }
  function crossCheck(bin, w, h, x, y, dx, dy, limit){
    var c = [0, 0, 0, 0, 0], px, py, nBack = 0, nFwd = 0;
    function black(a, b){ return a >= 0 && b >= 0 && a < w && b < h && bin[b * w + a] === 1; }
    function inb(a, b){ return a >= 0 && b >= 0 && a < w && b < h; }
    px = x - dx; py = y - dy;
    while (black(px, py)){ nBack++; px -= dx; py -= dy; if (nBack > limit) return null; }
    while (inb(px, py) && !black(px, py)){ c[1]++; px -= dx; py -= dy; if (c[1] > limit) return null; }
    while (black(px, py)){ c[0]++; px -= dx; py -= dy; if (c[0] > limit) return null; }
    px = x + dx; py = y + dy;
    while (black(px, py)){ nFwd++; px += dx; py += dy; if (nFwd > limit) return null; }
    while (inb(px, py) && !black(px, py)){ c[3]++; px += dx; py += dy; if (c[3] > limit) return null; }
    while (black(px, py)){ c[4]++; px += dx; py += dy; if (c[4] > limit) return null; }
    c[2] = 1 + nBack + nFwd;
    if (!c[0] || !c[1] || !c[3] || !c[4]) return null;
    var mod = ratioOk(c);
    if (!mod) return null;
    return {mod: mod, off: (nFwd - nBack) / 2};
  }
  function findFinders(bin, w, h){
    var cands = [], y, x;
    for (y = 0; y < h; y++){
      var rl = [], rs = [], rc = [], cur = bin[y * w], start = 0;
      for (x = 1; x <= w; x++){
        var v = x < w ? bin[y * w + x] : -1;
        if (v !== cur){ rl.push(x - start); rs.push(start); rc.push(cur); start = x; cur = v; }
      }
      for (var i = 0; i + 4 < rl.length; i++){
        if (rc[i] !== 1) continue;
        var c = [rl[i], rl[i+1], rl[i+2], rl[i+3], rl[i+4]];
        var mod = ratioOk(c);
        if (!mod) continue;
        var cx = Math.round(rs[i+2] + rl[i+2] / 2 - 0.5);
        var lim = Math.ceil(mod * 8);
        var vr = crossCheck(bin, w, h, cx, y, 0, 1, lim);
        if (!vr) continue;
        var cy = Math.round(y + vr.off);
        var hr = crossCheck(bin, w, h, cx, cy, 1, 0, lim);
        if (!hr) continue;
        var fx = cx + hr.off, fy = y + vr.off, size = (mod + vr.mod + hr.mod) / 3, found = false;
        for (var k = 0; k < cands.length; k++){
          var q = cands[k];
          if (Math.abs(q.x - fx) <= q.size && Math.abs(q.y - fy) <= q.size && Math.abs(q.size - size) <= q.size * 0.6){
            q.x = (q.x * q.n + fx) / (q.n + 1); q.y = (q.y * q.n + fy) / (q.n + 1); q.size = (q.size * q.n + size) / (q.n + 1); q.n++; found = true; break;
          }
        }
        if (!found) cands.push({x: fx, y: fy, size: size, n: 1});
      }
    }
    return cands.filter(function(q){ return q.n >= 3; }).sort(function(a, b){ return b.n - a.n; }).slice(0, 12);
  }
  function triples(cands){
    var out = [], n = cands.length;
    function dist(a, b){ return Math.sqrt((a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y)); }
    for (var i = 0; i < n; i++) for (var j = i + 1; j < n; j++) for (var k = j + 1; k < n; k++){
      var P = [cands[i], cands[j], cands[k]];
      var s = [P[0].size, P[1].size, P[2].size], mx = Math.max.apply(null, s), mn = Math.min.apply(null, s);
      if (mx / mn > 1.8) continue;
      var d = [dist(P[0], P[1]), dist(P[1], P[2]), dist(P[0], P[2])];   // sides opposite P2, P0, P1
      var idx = [0, 1, 2].sort(function(a, b){ return d[a] - d[b]; });
      var a = d[idx[0]], b = d[idx[1]], c = d[idx[2]];
      var avg = (s[0] + s[1] + s[2]) / 3;
      if (a < avg * 11) continue;
      var score = Math.abs(a - b) / (a + b) + Math.abs(c * c - (a * a + b * b)) / (c * c);
      if (score > 0.5) continue;
      var tlIdx = [2, 0, 1][idx[2]];          // vertex opposite the longest side
      var tl = P[tlIdx], o = P.filter(function(q, m){ return m !== tlIdx; });
      var cross = (o[0].x - tl.x) * (o[1].y - tl.y) - (o[0].y - tl.y) * (o[1].x - tl.x);
      var tr = cross > 0 ? o[0] : o[1], bl = cross > 0 ? o[1] : o[0];
      out.push({score: score, tl: tl, tr: tr, bl: bl, size: avg});
    }
    out.sort(function(a, b){ return a.score - b.score; });
    return out.slice(0, 4);
  }

  /* ---------- perspective transform: module coords -> image coords ---------- */
  function homography(src, dst){
    var A = [], i, j, k;
    for (i = 0; i < 4; i++){
      var x = src[i][0], y = src[i][1], u = dst[i][0], v = dst[i][1];
      A.push([x, y, 1, 0, 0, 0, -u * x, -u * y, u]);
      A.push([0, 0, 0, x, y, 1, -v * x, -v * y, v]);
    }
    for (i = 0; i < 8; i++){
      var piv = i;
      for (j = i + 1; j < 8; j++) if (Math.abs(A[j][i]) > Math.abs(A[piv][i])) piv = j;
      var t = A[i]; A[i] = A[piv]; A[piv] = t;
      if (Math.abs(A[i][i]) < 1e-12) return null;
      for (j = 0; j < 8; j++){
        if (j === i) continue;
        var f = A[j][i] / A[i][i];
        for (k = i; k < 9; k++) A[j][k] -= f * A[i][k];
      }
    }
    var h = [];
    for (i = 0; i < 8; i++) h.push(A[i][8] / A[i][i]);
    return function(px, py){
      var d = h[6] * px + h[7] * py + 1;
      return [(h[0] * px + h[1] * py + h[2]) / d, (h[3] * px + h[4] * py + h[5]) / d];
    };
  }
  function findAlignment(bin, w, h, tl, tr, bl, dim){
    var ux = [(tr.x - tl.x) / (dim - 7), (tr.y - tl.y) / (dim - 7)], uy = [(bl.x - tl.x) / (dim - 7), (bl.y - tl.y) / (dim - 7)];
    var gx = tl.x + (dim - 10) * ux[0] + (dim - 10) * uy[0], gy = tl.y + (dim - 10) * ux[1] + (dim - 10) * uy[1];
    var ms = (Math.sqrt(ux[0]*ux[0] + ux[1]*ux[1]) + Math.sqrt(uy[0]*uy[0] + uy[1]*uy[1])) / 2;
    var rad = Math.ceil(ms * 4), best = -1, sx = 0, sy = 0, cnt = 0;
    for (var oy = -rad; oy <= rad; oy++) for (var ox = -rad; ox <= rad; ox++){
      var cx = gx + ox, cy = gy + oy, score = 0;
      for (var dy = -2; dy <= 2; dy++) for (var dx = -2; dx <= 2; dx++){
        var px = Math.round(cx + dx * ux[0] + dy * uy[0]), py = Math.round(cy + dx * ux[1] + dy * uy[1]);
        if (px < 0 || py < 0 || px >= w || py >= h){ score -= 2; continue; }
        var want = (Math.max(Math.abs(dx), Math.abs(dy)) !== 1) ? 1 : 0;
        if (bin[py * w + px] === want) score++;
      }
      if (score > best){ best = score; sx = cx; sy = cy; cnt = 1; }
      else if (score === best){ sx += cx; sy += cy; cnt++; }
    }
    var bx = sx / cnt, by = sy / cnt;
    return best >= 21 ? [bx, by] : null;
  }

  /* module size measured along an arbitrary direction through a finder pattern center */
  function axisModule(bin, w, h, c, dx, dy){
    var len = Math.hypot(dx, dy); dx /= len; dy /= len;
    function sideDist(sign){
      var color = 1, trans = 0, t = 0;
      while (t < c.size * 6){
        t += 0.5;
        var px = Math.round(c.x + sign * dx * t), py = Math.round(c.y + sign * dy * t);
        if (px < 0 || py < 0 || px >= w || py >= h) return -1;
        var b = bin[py * w + px];
        if (b !== color){ color ^= 1; trans++; if (trans === 3) return t; }
      }
      return -1;
    }
    var a = sideDist(1), b = sideDist(-1);
    if (a < 0 || b < 0) return -1;
    return (a + b) / 7;
  }

  /* ---------- decode one candidate ---------- */
  function readFormat(g, size){
    function bit(x, y){ return g[y * size + x] ? 1 : 0; }
    var a = 0, b = 0, i;
    for (i = 0; i <= 5; i++) a |= bit(8, i) << i;
    a |= bit(8, 7) << 6; a |= bit(8, 8) << 7; a |= bit(7, 8) << 8;
    for (i = 9; i < 15; i++) a |= bit(14 - i, 8) << i;
    for (i = 0; i < 8; i++) b |= bit(size - 1 - i, 8) << i;
    for (i = 8; i < 15; i++) b |= bit(8, size - 15 + i) << i;
    var best = 99, bestData = -1;
    for (var d = 0; d < 32; d++){
      var da = popcount(a ^ FORMAT_CODES[d]), db = popcount(b ^ FORMAT_CODES[d]), dm = Math.min(da, db);
      if (dm < best){ best = dm; bestData = d; }
    }
    return best <= 3 ? bestData : -1;
  }
  function parseSegments(bytes, v){
    var bits = [], i, out = '', rawBytes = [];
    for (i = 0; i < bytes.length; i++) for (var k = 7; k >= 0; k--) bits.push((bytes[i] >> k) & 1);
    var pos = 0;
    function read(n){ var r = 0; for (var j = 0; j < n; j++){ if (pos >= bits.length) return -1; r = (r << 1) | bits[pos++]; } return r; }
    var ccBits = function(mode){
      var t = v <= 9 ? 0 : (v <= 26 ? 1 : 2);
      return {1: [10, 12, 14], 2: [9, 11, 13], 4: [8, 16, 16], 8: [8, 10, 12]}[mode][t];
    };
    var ALNUM = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:';
    function flushBytes(){
      if (!rawBytes.length) return;
      var s = '';
      for (var q = 0; q < rawBytes.length; q++) s += String.fromCharCode(rawBytes[q]);
      try { out += decodeURIComponent(escape(s)); } catch (e) { out += s; }
      rawBytes = [];
    }
    while (true){
      var mode = read(4);
      if (mode < 0 || mode === 0) break;
      if (mode === 7){
        var e0 = read(1);
        if (e0 === 0) read(7); else { var e1 = read(1); if (e1 === 0) read(14); else read(21); }
        continue;
      }
      if (mode === 3 || mode === 5 || mode === 9 || mode === 6 || mode === 10 || mode === 11 || mode === 12 || mode === 13 || mode === 14 || mode === 15){
        if (mode === 5 || mode === 9) continue;
        break;
      }
      if (!{1: 1, 2: 1, 4: 1, 8: 1}[mode]) break;
      var count = read(ccBits(mode));
      if (count < 0) return null;
      if (mode === 1){
        flushBytes();
        while (count >= 3){ var n3 = read(10); if (n3 < 0 || n3 > 999) return null; out += ('00' + n3).slice(-3); count -= 3; }
        if (count === 2){ var n2 = read(7); if (n2 < 0 || n2 > 99) return null; out += ('0' + n2).slice(-2); }
        else if (count === 1){ var n1 = read(4); if (n1 < 0 || n1 > 9) return null; out += n1; }
      } else if (mode === 2){
        flushBytes();
        while (count >= 2){ var a2 = read(11); if (a2 < 0 || a2 >= 45 * 45) return null; out += ALNUM[Math.floor(a2 / 45)] + ALNUM[a2 % 45]; count -= 2; }
        if (count === 1){ var a1 = read(6); if (a1 < 0 || a1 >= 45) return null; out += ALNUM[a1]; }
      } else if (mode === 4){
        for (var c = 0; c < count; c++){ var by = read(8); if (by < 0) return null; rawBytes.push(by); }
      } else {
        flushBytes();
        for (var c2 = 0; c2 < count; c2++){ if (read(13) < 0) return null; out += '?'; }
      }
    }
    flushBytes();
    return out;
  }
  function decodeAt(bin, w, h, tl, tr, bl, v){
    var dim = v * 4 + 17, size = dim;
    var p4 = null;
    if (v >= 2) p4 = findAlignment(bin, w, h, tl, tr, bl, dim);
    var src, dst;
    if (p4){
      src = [[3.5, 3.5], [dim - 3.5, 3.5], [3.5, dim - 3.5], [dim - 6.5, dim - 6.5]];
      dst = [[tl.x, tl.y], [tr.x, tr.y], [bl.x, bl.y], p4];
    } else {
      src = [[3.5, 3.5], [dim - 3.5, 3.5], [3.5, dim - 3.5], [dim - 3.5, dim - 3.5]];
      dst = [[tl.x, tl.y], [tr.x, tr.y], [bl.x, bl.y], [tr.x + bl.x - tl.x, tr.y + bl.y - tl.y]];
    }
    var H = homography(src, dst);
    if (!H) return null;
    var g = new Uint8Array(size * size), x, y;
    for (y = 0; y < size; y++) for (x = 0; x < size; x++){
      var p = H(x + 0.5, y + 0.5), px = Math.round(p[0]), py = Math.round(p[1]);
      if (px < 0 || py < 0 || px >= w || py >= h) return null;
      g[y * size + x] = bin[py * w + px];
    }
    var fmt = readFormat(g, size);
    if (fmt < 0) return null;
    var ecl = FORMAT_ECL[fmt >> 3], mask = fmt & 7;
    var func = functionMap(v), data = [], i = 0, total = Math.floor(rawModules(v) / 8), bitBuf = 0, bitCnt = 0;
    for (var right = size - 1; right >= 1; right -= 2){
      if (right === 6) right = 5;
      for (var vert = 0; vert < size; vert++){
        for (var j = 0; j < 2; j++){
          var xx = right - j, upward = ((right + 1) & 2) === 0, yy = upward ? size - 1 - vert : vert;
          if (func[yy * size + xx]) continue;
          var bit = g[yy * size + xx] ? 1 : 0;
          if (maskBit(mask, xx, yy)) bit ^= 1;
          bitBuf = (bitBuf << 1) | bit; bitCnt++;
          if (bitCnt === 8){ data.push(bitBuf); bitBuf = 0; bitCnt = 0; }
        }
      }
    }
    if (data.length < total) return null;
    data.length = total;
    var ecLen = ECC_PER_BLOCK[ecl][v], nBlocks = NUM_BLOCKS[ecl][v];
    var numShort = nBlocks - total % nBlocks, shortLen = Math.floor(total / nBlocks);
    var blocks = [], b;
    for (b = 0; b < nBlocks; b++) blocks.push({data: [], ec: [], dl: shortLen - ecLen + (b >= numShort ? 1 : 0)});
    var idx = 0;
    for (i = 0; i <= shortLen - ecLen; i++) for (b = 0; b < nBlocks; b++) if (i < blocks[b].dl) blocks[b].data.push(data[idx++]);
    for (i = 0; i < ecLen; i++) for (b = 0; b < nBlocks; b++) blocks[b].ec.push(data[idx++]);
    var all = [];
    for (b = 0; b < nBlocks; b++){
      var msg = blocks[b].data.concat(blocks[b].ec);
      if (!rsCorrect(msg, ecLen)) return null;
      for (i = 0; i < blocks[b].dl; i++) all.push(msg[i]);
    }
    var text = parseSegments(all, v);
    if (text === null) return null;
    var corners = [H(0, 0), H(dim, 0), H(0, dim), H(dim, dim)];
    return {text: text, version: v, ecl: 'LMQH'[ecl], corners: corners};
  }

  function decodeBin(bin, w, h){
    var cands = findFinders(bin, w, h);
    if (cands.length < 3) return null;
    var tr = triples(cands);
    for (var t = 0; t < tr.length; t++){
      var T = tr[t];
      var dTR = Math.sqrt(Math.pow(T.tr.x - T.tl.x, 2) + Math.pow(T.tr.y - T.tl.y, 2));
      var dBL = Math.sqrt(Math.pow(T.bl.x - T.tl.x, 2) + Math.pow(T.bl.y - T.tl.y, 2));
      var ux = T.tr.x - T.tl.x, uy = T.tr.y - T.tl.y, vx = T.bl.x - T.tl.x, vy = T.bl.y - T.tl.y;
      var ms = [axisModule(bin, w, h, T.tl, ux, uy), axisModule(bin, w, h, T.tl, vx, vy),
                axisModule(bin, w, h, T.tr, ux, uy), axisModule(bin, w, h, T.bl, vx, vy)].filter(function(m){ return m > 0; });
      var mod = ms.length ? ms.reduce(function(a, b){ return a + b; }, 0) / ms.length : T.size;
      var dimEst = (dTR + dBL) / 2 / mod + 7;
      var v0 = Math.round((dimEst - 17) / 4);
      var order = [v0, v0 + 1, v0 - 1, v0 + 2, v0 - 2];
      for (var o = 0; o < order.length; o++){
        var v = order[o];
        if (v < 1 || v > 40) continue;
        var r = null;
        try { r = decodeAt(bin, w, h, T.tl, T.tr, T.bl, v); } catch (e) { r = null; }
        if (r) return r;
      }
    }
    return null;
  }

  function decode(rgba, w, h, tryInverted){
    var bin = binarize(rgba, w, h), r = decodeBin(bin, w, h);
    if (!r && tryInverted){
      for (var i = 0; i < bin.length; i++) bin[i] ^= 1;
      r = decodeBin(bin, w, h);
    }
    return r;
  }
  return {decode: decode, _rs: rsCorrect, _alignPositions: alignPositions, _dbg: {binarize: binarize, findFinders: findFinders, triples: triples, decodeAt: decodeAt, readFormat: readFormat}};
})();
if (typeof module !== 'undefined') module.exports = QRDec;
